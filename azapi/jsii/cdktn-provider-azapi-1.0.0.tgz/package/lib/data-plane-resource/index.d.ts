/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataPlaneResourceConfig extends cdktn.TerraformMetaArguments {
    /**
    * A dynamic attribute that contains the request body.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/azure/azapi/2.13.0/docs/resources/data_plane_resource#body DataPlaneResource#body}
    */
    readonly body?: {
        [key: string]: any;
    };
    /**
    * A mapping of headers to be sent with the create request.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/azure/azapi/2.13.0/docs/resources/data_plane_resource#create_headers DataPlaneResource#create_headers}
    */
    readonly createHeaders?: {
        [key: string]: string;
    };
    /**
    * A mapping of query parameters to be sent with the create request.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/azure/azapi/2.13.0/docs/resources/data_plane_resource#create_query_parameters DataPlaneResource#create_query_parameters}
    */
    readonly createQueryParameters?: {
        [key: string]: string[];
    } | cdktn.IResolvable;
    /**
    * A mapping of headers to be sent with the delete request.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/azure/azapi/2.13.0/docs/resources/data_plane_resource#delete_headers DataPlaneResource#delete_headers}
    */
    readonly deleteHeaders?: {
        [key: string]: string;
    };
    /**
    * A mapping of query parameters to be sent with the delete request.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/azure/azapi/2.13.0/docs/resources/data_plane_resource#delete_query_parameters DataPlaneResource#delete_query_parameters}
    */
    readonly deleteQueryParameters?: {
        [key: string]: string[];
    } | cdktn.IResolvable;
    /**
    * A dynamic attribute that contains the request body.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/azure/azapi/2.13.0/docs/resources/data_plane_resource#ignore_casing DataPlaneResource#ignore_casing}
    */
    readonly ignoreCasing?: boolean | cdktn.IResolvable;
    /**
    * Whether ignore not returned properties like credentials in `body` to suppress plan-diff. It's recommend to enable this option when some sensitive properties are not returned in response body, instead of setting them in `lifecycle.ignore_changes` because it will make the sensitive fields unable to update.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/azure/azapi/2.13.0/docs/resources/data_plane_resource#ignore_missing_property DataPlaneResource#ignore_missing_property}
    */
    readonly ignoreMissingProperty?: boolean | cdktn.IResolvable;
    /**
    * A list of ARM resource IDs which are used to avoid create/modify/delete azapi resources at the same time.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/azure/azapi/2.13.0/docs/resources/data_plane_resource#locks DataPlaneResource#locks}
    */
    readonly locks?: string[];
    /**
    * Specifies the name (identifier segment) of the data plane resource. Changing this forces a new resource to be created.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/azure/azapi/2.13.0/docs/resources/data_plane_resource#name DataPlaneResource#name}
    */
    readonly name?: string;
    /**
    * The ID of the azure resource in which this resource is created. Changing this forces a new resource to be created.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/azure/azapi/2.13.0/docs/resources/data_plane_resource#parent_id DataPlaneResource#parent_id}
    */
    readonly parentId: string;
    /**
    * A mapping of headers to be sent with the read request.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/azure/azapi/2.13.0/docs/resources/data_plane_resource#read_headers DataPlaneResource#read_headers}
    */
    readonly readHeaders?: {
        [key: string]: string;
    };
    /**
    * A mapping of query parameters to be sent with the read request.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/azure/azapi/2.13.0/docs/resources/data_plane_resource#read_query_parameters DataPlaneResource#read_query_parameters}
    */
    readonly readQueryParameters?: {
        [key: string]: string[];
    } | cdktn.IResolvable;
    /**
    * Will trigger a replace of the resource when the value changes and is not `null`. This can be used by practitioners to force a replace of the resource when certain values change, e.g. changing the SKU of a virtual machine based on the value of variables or locals. The value is a `dynamic`, so practitioners can compose the input however they wish. For a "break glass" set the value to `null` to prevent the plan modifier taking effect.
    * If you have `null` values that you do want to be tracked as affecting the resource replacement, include these inside an object.
    * Advanced use cases are possible and resource replacement can be triggered by values external to the resource, for example when a dependent resource changes.
    *
    * e.g. to replace a resource when either the SKU or os_type attributes change:
    *
    * ```hcl
    * resource "azapi_data_plane_resource" "example" {
    *   name = var.name
    *   type = "Microsoft.AppConfiguration/configurationStores/keyValues@1.0"
    *   body = {
    *     properties = {
    *       sku   = var.sku
    *       zones = var.zones
    *     }
    *   }
    *
    *   replace_triggers_external_values = [
    *     var.sku,
    *     var.zones,
    *   ]
    * }
    * ```
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/azure/azapi/2.13.0/docs/resources/data_plane_resource#replace_triggers_external_values DataPlaneResource#replace_triggers_external_values}
    */
    readonly replaceTriggersExternalValues?: {
        [key: string]: any;
    };
    /**
    * A list of paths in the current Terraform configuration. When the values at these paths change, the resource will be replaced.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/azure/azapi/2.13.0/docs/resources/data_plane_resource#replace_triggers_refs DataPlaneResource#replace_triggers_refs}
    */
    readonly replaceTriggersRefs?: string[];
    /**
    * The attribute can accept either a list or a map.
    *
    * - **List**: A list of paths that need to be exported from the response body. Setting it to `["*"]` will export the full response body. Here's an example. If it sets to `["properties.loginServer", "properties.policies.quarantinePolicy.status"]`, it will set the following HCL object to the computed property output.
    *
    * 	```text
    * 	{
    * 		properties = {
    * 			loginServer = "registry1.azurecr.io"
    * 			policies = {
    * 				quarantinePolicy = {
    * 					status = "disabled"
    * 				}
    * 			}
    * 		}
    * 	}
    * 	```
    *
    * - **Map**: A map where the key is the name for the result and the value is a JMESPath query string to filter the response. Here's an example. If it sets to `{"login_server": "properties.loginServer", "quarantine_status": "properties.policies.quarantinePolicy.status"}`, it will set the following HCL object to the computed property output.
    *
    * 	```text
    * 	{
    * 		"login_server" = "registry1.azurecr.io"
    * 		"quarantine_status" = "disabled"
    * 	}
    * 	```
    *
    * To learn more about JMESPath, visit [JMESPath](https://jmespath.org/).
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/azure/azapi/2.13.0/docs/resources/data_plane_resource#response_export_values DataPlaneResource#response_export_values}
    */
    readonly responseExportValues?: {
        [key: string]: any;
    };
    /**
    * The retry object supports the following attributes:
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/azure/azapi/2.13.0/docs/resources/data_plane_resource#retry DataPlaneResource#retry}
    */
    readonly retry?: DataPlaneResourceRetry;
    /**
    * A dynamic attribute that contains the write-only properties of the request body. This will be merge-patched to the body to construct the actual request body. If a property is defined in both `body` and `sensitive_body`, the `sensitive_body` value takes precedence.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/azure/azapi/2.13.0/docs/resources/data_plane_resource#sensitive_body DataPlaneResource#sensitive_body}
    */
    readonly sensitiveBody?: {
        [key: string]: any;
    };
    /**
    * A map where the key is the path to the property in `sensitive_body` and the value is the version of the property. The key is a string in the format of `path.to.property[index].subproperty`, where `index` is the index of the item in an array. When the version is changed, the property will be included in the request body, otherwise it will be omitted from the request body.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/azure/azapi/2.13.0/docs/resources/data_plane_resource#sensitive_body_version DataPlaneResource#sensitive_body_version}
    */
    readonly sensitiveBodyVersion?: {
        [key: string]: string;
    };
    /**
    * In a format like `<resource-type>@<api-version>`. `<resource-type>` is the Azure resource type, for example, `Microsoft.Storage/storageAccounts`. `<api-version>` is version of the API used to manage this azure resource. For a list of supported data plane resource types, see the [Available Resources](https://registry.terraform.io/providers/Azure/azapi/latest/docs/resources/data_plane_resource#available-resources) documentation.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/azure/azapi/2.13.0/docs/resources/data_plane_resource#type DataPlaneResource#type}
    */
    readonly type: string;
    /**
    * A mapping of headers to be sent with the update request.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/azure/azapi/2.13.0/docs/resources/data_plane_resource#update_headers DataPlaneResource#update_headers}
    */
    readonly updateHeaders?: {
        [key: string]: string;
    };
    /**
    * A mapping of query parameters to be sent with the update request.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/azure/azapi/2.13.0/docs/resources/data_plane_resource#update_query_parameters DataPlaneResource#update_query_parameters}
    */
    readonly updateQueryParameters?: {
        [key: string]: string[];
    } | cdktn.IResolvable;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/azure/azapi/2.13.0/docs/resources/data_plane_resource#timeouts DataPlaneResource#timeouts}
    */
    readonly timeouts?: DataPlaneResourceTimeouts;
}
export interface DataPlaneResourceRetry {
    /**
    * A list of regular expressions to match against error messages. If any of the regular expressions match, the request will be retried.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/azure/azapi/2.13.0/docs/resources/data_plane_resource#error_message_regex DataPlaneResource#error_message_regex}
    */
    readonly errorMessageRegex: string[];
    /**
    * The base number of seconds to wait between retries.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/azure/azapi/2.13.0/docs/resources/data_plane_resource#interval_seconds DataPlaneResource#interval_seconds}
    */
    readonly intervalSeconds?: number;
    /**
    * The maximum number of seconds to wait between retries.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/azure/azapi/2.13.0/docs/resources/data_plane_resource#max_interval_seconds DataPlaneResource#max_interval_seconds}
    */
    readonly maxIntervalSeconds?: number;
    /**
    * The multiplier to apply to the interval between retries.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/azure/azapi/2.13.0/docs/resources/data_plane_resource#multiplier DataPlaneResource#multiplier}
    */
    readonly multiplier?: number;
    /**
    * The randomization factor to apply to the interval between retries. The formula for the randomized interval is: `RetryInterval * (random value in range [1 - RandomizationFactor, 1 + RandomizationFactor])`. Therefore set to zero `0.0` for no randomization.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/azure/azapi/2.13.0/docs/resources/data_plane_resource#randomization_factor DataPlaneResource#randomization_factor}
    */
    readonly randomizationFactor?: number;
}
export declare function dataPlaneResourceRetryToTerraform(struct?: DataPlaneResourceRetry | cdktn.IResolvable): any;
export declare function dataPlaneResourceRetryToHclTerraform(struct?: DataPlaneResourceRetry | cdktn.IResolvable): any;
export declare class DataPlaneResourceRetryOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataPlaneResourceRetry | cdktn.IResolvable | undefined;
    set internalValue(value: DataPlaneResourceRetry | cdktn.IResolvable | undefined);
    private _errorMessageRegex?;
    get errorMessageRegex(): string[];
    set errorMessageRegex(value: string[]);
    get errorMessageRegexInput(): string[] | undefined;
    private _intervalSeconds?;
    get intervalSeconds(): number;
    set intervalSeconds(value: number);
    resetIntervalSeconds(): void;
    get intervalSecondsInput(): number | undefined;
    private _maxIntervalSeconds?;
    get maxIntervalSeconds(): number;
    set maxIntervalSeconds(value: number);
    resetMaxIntervalSeconds(): void;
    get maxIntervalSecondsInput(): number | undefined;
    private _multiplier?;
    get multiplier(): number;
    set multiplier(value: number);
    resetMultiplier(): void;
    get multiplierInput(): number | undefined;
    private _randomizationFactor?;
    get randomizationFactor(): number;
    set randomizationFactor(value: number);
    resetRandomizationFactor(): void;
    get randomizationFactorInput(): number | undefined;
}
export interface DataPlaneResourceTimeouts {
    /**
    * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/azure/azapi/2.13.0/docs/resources/data_plane_resource#create DataPlaneResource#create}
    */
    readonly create?: string;
    /**
    * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours). Setting a timeout for a Delete operation is only applicable if changes are saved into state before the destroy operation occurs.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/azure/azapi/2.13.0/docs/resources/data_plane_resource#delete DataPlaneResource#delete}
    */
    readonly delete?: string;
    /**
    * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours). Read operations occur during any refresh or planning operation when refresh is enabled.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/azure/azapi/2.13.0/docs/resources/data_plane_resource#read DataPlaneResource#read}
    */
    readonly read?: string;
    /**
    * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/azure/azapi/2.13.0/docs/resources/data_plane_resource#update DataPlaneResource#update}
    */
    readonly update?: string;
}
export declare function dataPlaneResourceTimeoutsToTerraform(struct?: DataPlaneResourceTimeouts | cdktn.IResolvable): any;
export declare function dataPlaneResourceTimeoutsToHclTerraform(struct?: DataPlaneResourceTimeouts | cdktn.IResolvable): any;
export declare class DataPlaneResourceTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataPlaneResourceTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: DataPlaneResourceTimeouts | cdktn.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
    private _read?;
    get read(): string;
    set read(value: string);
    resetRead(): void;
    get readInput(): string | undefined;
    private _update?;
    get update(): string;
    set update(value: string);
    resetUpdate(): void;
    get updateInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/azure/azapi/2.13.0/docs/resources/data_plane_resource azapi_data_plane_resource}
*/
export declare class DataPlaneResource extends cdktn.TerraformResource {
    static readonly tfResourceType = "azapi_data_plane_resource";
    /**
    * Generates CDKTN code for importing a DataPlaneResource resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataPlaneResource to import
    * @param importFromId The id of the existing DataPlaneResource that should be imported. Refer to the {@link https://registry.terraform.io/providers/azure/azapi/2.13.0/docs/resources/data_plane_resource#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataPlaneResource to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/azure/azapi/2.13.0/docs/resources/data_plane_resource azapi_data_plane_resource} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataPlaneResourceConfig
    */
    constructor(scope: Construct, id: string, config: DataPlaneResourceConfig);
    private _body?;
    get body(): {
        [key: string]: any;
    };
    set body(value: {
        [key: string]: any;
    });
    resetBody(): void;
    get bodyInput(): {
        [key: string]: any;
    } | undefined;
    private _createHeaders?;
    get createHeaders(): {
        [key: string]: string;
    };
    set createHeaders(value: {
        [key: string]: string;
    });
    resetCreateHeaders(): void;
    get createHeadersInput(): {
        [key: string]: string;
    } | undefined;
    private _createQueryParameters?;
    get createQueryParameters(): {
        [key: string]: string[];
    } | cdktn.IResolvable;
    set createQueryParameters(value: {
        [key: string]: string[];
    } | cdktn.IResolvable);
    resetCreateQueryParameters(): void;
    get createQueryParametersInput(): cdktn.IResolvable | {
        [key: string]: string[];
    } | undefined;
    private _deleteHeaders?;
    get deleteHeaders(): {
        [key: string]: string;
    };
    set deleteHeaders(value: {
        [key: string]: string;
    });
    resetDeleteHeaders(): void;
    get deleteHeadersInput(): {
        [key: string]: string;
    } | undefined;
    private _deleteQueryParameters?;
    get deleteQueryParameters(): {
        [key: string]: string[];
    } | cdktn.IResolvable;
    set deleteQueryParameters(value: {
        [key: string]: string[];
    } | cdktn.IResolvable);
    resetDeleteQueryParameters(): void;
    get deleteQueryParametersInput(): cdktn.IResolvable | {
        [key: string]: string[];
    } | undefined;
    get id(): string;
    private _ignoreCasing?;
    get ignoreCasing(): boolean | cdktn.IResolvable;
    set ignoreCasing(value: boolean | cdktn.IResolvable);
    resetIgnoreCasing(): void;
    get ignoreCasingInput(): boolean | cdktn.IResolvable | undefined;
    private _ignoreMissingProperty?;
    get ignoreMissingProperty(): boolean | cdktn.IResolvable;
    set ignoreMissingProperty(value: boolean | cdktn.IResolvable);
    resetIgnoreMissingProperty(): void;
    get ignoreMissingPropertyInput(): boolean | cdktn.IResolvable | undefined;
    private _locks?;
    get locks(): string[];
    set locks(value: string[]);
    resetLocks(): void;
    get locksInput(): string[] | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _output;
    get output(): cdktn.AnyMap;
    private _parentId?;
    get parentId(): string;
    set parentId(value: string);
    get parentIdInput(): string | undefined;
    private _readHeaders?;
    get readHeaders(): {
        [key: string]: string;
    };
    set readHeaders(value: {
        [key: string]: string;
    });
    resetReadHeaders(): void;
    get readHeadersInput(): {
        [key: string]: string;
    } | undefined;
    private _readQueryParameters?;
    get readQueryParameters(): {
        [key: string]: string[];
    } | cdktn.IResolvable;
    set readQueryParameters(value: {
        [key: string]: string[];
    } | cdktn.IResolvable);
    resetReadQueryParameters(): void;
    get readQueryParametersInput(): cdktn.IResolvable | {
        [key: string]: string[];
    } | undefined;
    private _replaceTriggersExternalValues?;
    get replaceTriggersExternalValues(): {
        [key: string]: any;
    };
    set replaceTriggersExternalValues(value: {
        [key: string]: any;
    });
    resetReplaceTriggersExternalValues(): void;
    get replaceTriggersExternalValuesInput(): {
        [key: string]: any;
    } | undefined;
    private _replaceTriggersRefs?;
    get replaceTriggersRefs(): string[];
    set replaceTriggersRefs(value: string[]);
    resetReplaceTriggersRefs(): void;
    get replaceTriggersRefsInput(): string[] | undefined;
    private _responseExportValues?;
    get responseExportValues(): {
        [key: string]: any;
    };
    set responseExportValues(value: {
        [key: string]: any;
    });
    resetResponseExportValues(): void;
    get responseExportValuesInput(): {
        [key: string]: any;
    } | undefined;
    private _retry;
    get retry(): DataPlaneResourceRetryOutputReference;
    putRetry(value: DataPlaneResourceRetry): void;
    resetRetry(): void;
    get retryInput(): cdktn.IResolvable | DataPlaneResourceRetry | undefined;
    private _sensitiveBody?;
    /**
    * @deprecated Write-only: the provider never returns this value; reading it always yields null by protocol contract. The getter remains for compatibility and will be removed in a future prebuilt-provider major.
    */
    get sensitiveBody(): {
        [key: string]: any;
    };
    set sensitiveBody(value: {
        [key: string]: any;
    });
    resetSensitiveBody(): void;
    get sensitiveBodyInput(): {
        [key: string]: any;
    } | undefined;
    private _sensitiveBodyVersion?;
    get sensitiveBodyVersion(): {
        [key: string]: string;
    };
    set sensitiveBodyVersion(value: {
        [key: string]: string;
    });
    resetSensitiveBodyVersion(): void;
    get sensitiveBodyVersionInput(): {
        [key: string]: string;
    } | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    get typeInput(): string | undefined;
    private _updateHeaders?;
    get updateHeaders(): {
        [key: string]: string;
    };
    set updateHeaders(value: {
        [key: string]: string;
    });
    resetUpdateHeaders(): void;
    get updateHeadersInput(): {
        [key: string]: string;
    } | undefined;
    private _updateQueryParameters?;
    get updateQueryParameters(): {
        [key: string]: string[];
    } | cdktn.IResolvable;
    set updateQueryParameters(value: {
        [key: string]: string[];
    } | cdktn.IResolvable);
    resetUpdateQueryParameters(): void;
    get updateQueryParametersInput(): cdktn.IResolvable | {
        [key: string]: string[];
    } | undefined;
    private _timeouts;
    get timeouts(): DataPlaneResourceTimeoutsOutputReference;
    putTimeouts(value: DataPlaneResourceTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | DataPlaneResourceTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
