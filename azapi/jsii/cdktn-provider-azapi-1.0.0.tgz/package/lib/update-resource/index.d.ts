/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface UpdateResourceConfig extends cdktn.TerraformMetaArguments {
    /**
    * A dynamic attribute that contains the request body.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/azure/azapi/2.13.0/docs/resources/update_resource#body UpdateResource#body}
    */
    readonly body?: {
        [key: string]: any;
    };
    /**
    * Whether ignore the casing of the property names in the response body.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/azure/azapi/2.13.0/docs/resources/update_resource#ignore_casing UpdateResource#ignore_casing}
    */
    readonly ignoreCasing?: boolean | cdktn.IResolvable;
    /**
    * Whether ignore not returned properties like credentials in `body` to suppress plan-diff. It's recommend to enable this option when some sensitive properties are not returned in response body, instead of setting them in `lifecycle.ignore_changes` because it will make the sensitive fields unable to update.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/azure/azapi/2.13.0/docs/resources/update_resource#ignore_missing_property UpdateResource#ignore_missing_property}
    */
    readonly ignoreMissingProperty?: boolean | cdktn.IResolvable;
    /**
    * A list of list property paths where items not specified in configuration should be ignored. This is intended for partial list management when combined with `list_unique_id_property` (for example, to avoid perpetual drift from server-side ordering).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/azure/azapi/2.13.0/docs/resources/update_resource#ignore_other_items_in_list UpdateResource#ignore_other_items_in_list}
    */
    readonly ignoreOtherItemsInList?: string[];
    /**
    * A mapping of list property paths to the field name used as a unique identifier when comparing and merging list items. When not set, list items are matched by a `name` property (if present) or by list ordering. To match using multiple fields, specify a comma-separated list of field names (e.g., `"category, categoryGroup"`).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/azure/azapi/2.13.0/docs/resources/update_resource#list_unique_id_property UpdateResource#list_unique_id_property}
    */
    readonly listUniqueIdProperty?: {
        [key: string]: string;
    };
    /**
    * A list of ARM resource IDs which are used to avoid create/modify/delete azapi resources at the same time.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/azure/azapi/2.13.0/docs/resources/update_resource#locks UpdateResource#locks}
    */
    readonly locks?: string[];
    /**
    * Specifies the name of the Azure resource. Changing this forces a new resource to be created.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/azure/azapi/2.13.0/docs/resources/update_resource#name UpdateResource#name}
    */
    readonly name?: string;
    /**
    * The ID of the azure resource in which this resource is created. It supports different kinds of deployment scope for **top level** resources:
    *
    * - resource group scope: `parent_id` should be the ID of a resource group, it's recommended to manage a resource group by azurerm_resource_group.
    * - management group scope: `parent_id` should be the ID of a management group, it's recommended to manage a management group by azurerm_management_group.
    * - extension scope: `parent_id` should be the ID of the resource you're adding the extension to.
    * - subscription scope: `parent_id` should be like \x60/subscriptions/00000000-0000-0000-0000-000000000000\x60
    * - tenant scope: `parent_id` should be /
    *
    * For child level resources, the `parent_id` should be the ID of its parent resource, for example, subnet resource's `parent_id` is the ID of the vnet.
    *
    * For type `Microsoft.Resources/resourceGroups`, the `parent_id` could be omitted, it defaults to subscription ID specified in provider or the default subscription (You could check the default subscription by azure cli command: `az account show`).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/azure/azapi/2.13.0/docs/resources/update_resource#parent_id UpdateResource#parent_id}
    */
    readonly parentId?: string;
    /**
    * A mapping of headers to be sent with the read request.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/azure/azapi/2.13.0/docs/resources/update_resource#read_headers UpdateResource#read_headers}
    */
    readonly readHeaders?: {
        [key: string]: string;
    };
    /**
    * Overrides the default `GET` request used to read the resource. When configured, the provider sends the specified action request instead of `GET` and uses its response for all read processing, including refreshing `body` and `output`. When omitted, the provider reads the resource with `GET`.
    *
    * ~> **Warning:** Do not use `read_override` with sensitive values. Action responses are stored in state through `body` and `output`, and `read_override` cannot be combined with `sensitive_body`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/azure/azapi/2.13.0/docs/resources/update_resource#read_override UpdateResource#read_override}
    */
    readonly readOverride?: UpdateResourceReadOverride;
    /**
    * A mapping of query parameters to be sent with the read request.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/azure/azapi/2.13.0/docs/resources/update_resource#read_query_parameters UpdateResource#read_query_parameters}
    */
    readonly readQueryParameters?: {
        [key: string]: string[];
    } | cdktn.IResolvable;
    /**
    * Will trigger a replace of the resource when the value changes and is not `null`. This can be used by practitioners to force a replace of the resource when certain values change, e.g. changing the SKU of a virtual machine based on the value of variables or locals. The value is a `dynamic`, so practitioners can compose the input however they wish. For a "break glass" set the value to `null` to prevent the plan modifier taking effect.
    * If you have `null` values that you do want to be tracked as affecting the resource replacement, include these inside an object.
    * Advanced use cases are possible and resource replacement can be triggered by values external to the resource, for example when a dependent resource changes.
    *
    * e.g. to replace a resource when either the SKU or os_type attributes change:
    *
    * ```hcl
    * resource "azapi_update_resource" "example" {
    *   resource_id = "/subscriptions/00000000-0000-0000-0000-000000000000/resourceGroups/example/providers/Microsoft.Network/publicIPAddresses/example"
    *   type        = "Microsoft.Network/publicIPAddresses@2023-11-01"
    *   body = {
    *     properties = {
    *       sku   = var.sku
    *       zones = var.zones
    *     }
    *   }
    *
    *   replace_triggers_external_values = [
    *     var.sku,
    *     var.zones,
    *   ]
    * }
    * ```
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/azure/azapi/2.13.0/docs/resources/update_resource#replace_triggers_external_values UpdateResource#replace_triggers_external_values}
    */
    readonly replaceTriggersExternalValues?: {
        [key: string]: any;
    };
    /**
    * The ID of an existing Azure source.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/azure/azapi/2.13.0/docs/resources/update_resource#resource_id UpdateResource#resource_id}
    */
    readonly resourceId?: string;
    /**
    * The attribute can accept either a list or a map.
    *
    * - **List**: A list of paths that need to be exported from the response body. Setting it to `["*"]` will export the full response body. Here's an example. If it sets to `["properties.loginServer", "properties.policies.quarantinePolicy.status"]`, it will set the following HCL object to the computed property output.
    *
    * 	```text
    * 	{
    * 		properties = {
    * 			loginServer = "registry1.azurecr.io"
    * 			policies = {
    * 				quarantinePolicy = {
    * 					status = "disabled"
    * 				}
    * 			}
    * 		}
    * 	}
    * 	```
    *
    * - **Map**: A map where the key is the name for the result and the value is a JMESPath query string to filter the response. Here's an example. If it sets to `{"login_server": "properties.loginServer", "quarantine_status": "properties.policies.quarantinePolicy.status"}`, it will set the following HCL object to the computed property output.
    *
    * 	```text
    * 	{
    * 		"login_server" = "registry1.azurecr.io"
    * 		"quarantine_status" = "disabled"
    * 	}
    * 	```
    *
    * To learn more about JMESPath, visit [JMESPath](https://jmespath.org/).
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/azure/azapi/2.13.0/docs/resources/update_resource#response_export_values UpdateResource#response_export_values}
    */
    readonly responseExportValues?: {
        [key: string]: any;
    };
    /**
    * The retry object supports the following attributes:
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/azure/azapi/2.13.0/docs/resources/update_resource#retry UpdateResource#retry}
    */
    readonly retry?: UpdateResourceRetry;
    /**
    * A dynamic attribute that contains the write-only properties of the request body. This will be merge-patched to the body to construct the actual request body. If a property is defined in both `body` and `sensitive_body`, the `sensitive_body` value takes precedence.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/azure/azapi/2.13.0/docs/resources/update_resource#sensitive_body UpdateResource#sensitive_body}
    */
    readonly sensitiveBody?: {
        [key: string]: any;
    };
    /**
    * A map where the key is the path to the property in `sensitive_body` and the value is the version of the property. The key is a string in the format of `path.to.property[index].subproperty`, where `index` is the index of the item in an array. When the version is changed, the property will be included in the request body, otherwise it will be omitted from the request body.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/azure/azapi/2.13.0/docs/resources/update_resource#sensitive_body_version UpdateResource#sensitive_body_version}
    */
    readonly sensitiveBodyVersion?: {
        [key: string]: string;
    };
    /**
    * In a format like `<resource-type>@<api-version>`. `<resource-type>` is the Azure resource type, for example, `Microsoft.Storage/storageAccounts`. `<api-version>` is version of the API used to manage this azure resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/azure/azapi/2.13.0/docs/resources/update_resource#type UpdateResource#type}
    */
    readonly type: string;
    /**
    * A mapping of headers to be sent with the update request.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/azure/azapi/2.13.0/docs/resources/update_resource#update_headers UpdateResource#update_headers}
    */
    readonly updateHeaders?: {
        [key: string]: string;
    };
    /**
    * A mapping of query parameters to be sent with the update request.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/azure/azapi/2.13.0/docs/resources/update_resource#update_query_parameters UpdateResource#update_query_parameters}
    */
    readonly updateQueryParameters?: {
        [key: string]: string[];
    } | cdktn.IResolvable;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/azure/azapi/2.13.0/docs/resources/update_resource#timeouts UpdateResource#timeouts}
    */
    readonly timeouts?: UpdateResourceTimeouts;
}
export interface UpdateResourceReadOverride {
    /**
    * The name of the action appended to the resource ID, for example `list`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/azure/azapi/2.13.0/docs/resources/update_resource#action UpdateResource#action}
    */
    readonly action: string;
    /**
    * The HTTP method used to read the resource. The only supported value is `POST`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/azure/azapi/2.13.0/docs/resources/update_resource#method UpdateResource#method}
    */
    readonly method: string;
}
export declare function updateResourceReadOverrideToTerraform(struct?: UpdateResourceReadOverride | cdktn.IResolvable): any;
export declare function updateResourceReadOverrideToHclTerraform(struct?: UpdateResourceReadOverride | cdktn.IResolvable): any;
export declare class UpdateResourceReadOverrideOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): UpdateResourceReadOverride | cdktn.IResolvable | undefined;
    set internalValue(value: UpdateResourceReadOverride | cdktn.IResolvable | undefined);
    private _action?;
    get action(): string;
    set action(value: string);
    get actionInput(): string | undefined;
    private _method?;
    get method(): string;
    set method(value: string);
    get methodInput(): string | undefined;
}
export interface UpdateResourceRetry {
    /**
    * A list of regular expressions to match against error messages. If any of the regular expressions match, the request will be retried.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/azure/azapi/2.13.0/docs/resources/update_resource#error_message_regex UpdateResource#error_message_regex}
    */
    readonly errorMessageRegex: string[];
    /**
    * The base number of seconds to wait between retries.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/azure/azapi/2.13.0/docs/resources/update_resource#interval_seconds UpdateResource#interval_seconds}
    */
    readonly intervalSeconds?: number;
    /**
    * The maximum number of seconds to wait between retries.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/azure/azapi/2.13.0/docs/resources/update_resource#max_interval_seconds UpdateResource#max_interval_seconds}
    */
    readonly maxIntervalSeconds?: number;
    /**
    * The multiplier to apply to the interval between retries.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/azure/azapi/2.13.0/docs/resources/update_resource#multiplier UpdateResource#multiplier}
    */
    readonly multiplier?: number;
    /**
    * The randomization factor to apply to the interval between retries. The formula for the randomized interval is: `RetryInterval * (random value in range [1 - RandomizationFactor, 1 + RandomizationFactor])`. Therefore set to zero `0.0` for no randomization.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/azure/azapi/2.13.0/docs/resources/update_resource#randomization_factor UpdateResource#randomization_factor}
    */
    readonly randomizationFactor?: number;
}
export declare function updateResourceRetryToTerraform(struct?: UpdateResourceRetry | cdktn.IResolvable): any;
export declare function updateResourceRetryToHclTerraform(struct?: UpdateResourceRetry | cdktn.IResolvable): any;
export declare class UpdateResourceRetryOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): UpdateResourceRetry | cdktn.IResolvable | undefined;
    set internalValue(value: UpdateResourceRetry | cdktn.IResolvable | undefined);
    private _errorMessageRegex?;
    get errorMessageRegex(): string[];
    set errorMessageRegex(value: string[]);
    get errorMessageRegexInput(): string[] | undefined;
    private _intervalSeconds?;
    get intervalSeconds(): number;
    set intervalSeconds(value: number);
    resetIntervalSeconds(): void;
    get intervalSecondsInput(): number | undefined;
    private _maxIntervalSeconds?;
    get maxIntervalSeconds(): number;
    set maxIntervalSeconds(value: number);
    resetMaxIntervalSeconds(): void;
    get maxIntervalSecondsInput(): number | undefined;
    private _multiplier?;
    get multiplier(): number;
    set multiplier(value: number);
    resetMultiplier(): void;
    get multiplierInput(): number | undefined;
    private _randomizationFactor?;
    get randomizationFactor(): number;
    set randomizationFactor(value: number);
    resetRandomizationFactor(): void;
    get randomizationFactorInput(): number | undefined;
}
export interface UpdateResourceTimeouts {
    /**
    * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/azure/azapi/2.13.0/docs/resources/update_resource#create UpdateResource#create}
    */
    readonly create?: string;
    /**
    * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours). Setting a timeout for a Delete operation is only applicable if changes are saved into state before the destroy operation occurs.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/azure/azapi/2.13.0/docs/resources/update_resource#delete UpdateResource#delete}
    */
    readonly delete?: string;
    /**
    * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours). Read operations occur during any refresh or planning operation when refresh is enabled.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/azure/azapi/2.13.0/docs/resources/update_resource#read UpdateResource#read}
    */
    readonly read?: string;
    /**
    * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/azure/azapi/2.13.0/docs/resources/update_resource#update UpdateResource#update}
    */
    readonly update?: string;
}
export declare function updateResourceTimeoutsToTerraform(struct?: UpdateResourceTimeouts | cdktn.IResolvable): any;
export declare function updateResourceTimeoutsToHclTerraform(struct?: UpdateResourceTimeouts | cdktn.IResolvable): any;
export declare class UpdateResourceTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): UpdateResourceTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: UpdateResourceTimeouts | cdktn.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
    private _read?;
    get read(): string;
    set read(value: string);
    resetRead(): void;
    get readInput(): string | undefined;
    private _update?;
    get update(): string;
    set update(value: string);
    resetUpdate(): void;
    get updateInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/azure/azapi/2.13.0/docs/resources/update_resource azapi_update_resource}
*/
export declare class UpdateResource extends cdktn.TerraformResource {
    static readonly tfResourceType = "azapi_update_resource";
    /**
    * Generates CDKTN code for importing a UpdateResource resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the UpdateResource to import
    * @param importFromId The id of the existing UpdateResource that should be imported. Refer to the {@link https://registry.terraform.io/providers/azure/azapi/2.13.0/docs/resources/update_resource#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the UpdateResource to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/azure/azapi/2.13.0/docs/resources/update_resource azapi_update_resource} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options UpdateResourceConfig
    */
    constructor(scope: Construct, id: string, config: UpdateResourceConfig);
    private _body?;
    get body(): {
        [key: string]: any;
    };
    set body(value: {
        [key: string]: any;
    });
    resetBody(): void;
    get bodyInput(): {
        [key: string]: any;
    } | undefined;
    get id(): string;
    private _ignoreCasing?;
    get ignoreCasing(): boolean | cdktn.IResolvable;
    set ignoreCasing(value: boolean | cdktn.IResolvable);
    resetIgnoreCasing(): void;
    get ignoreCasingInput(): boolean | cdktn.IResolvable | undefined;
    private _ignoreMissingProperty?;
    get ignoreMissingProperty(): boolean | cdktn.IResolvable;
    set ignoreMissingProperty(value: boolean | cdktn.IResolvable);
    resetIgnoreMissingProperty(): void;
    get ignoreMissingPropertyInput(): boolean | cdktn.IResolvable | undefined;
    private _ignoreOtherItemsInList?;
    get ignoreOtherItemsInList(): string[];
    set ignoreOtherItemsInList(value: string[]);
    resetIgnoreOtherItemsInList(): void;
    get ignoreOtherItemsInListInput(): string[] | undefined;
    private _listUniqueIdProperty?;
    get listUniqueIdProperty(): {
        [key: string]: string;
    };
    set listUniqueIdProperty(value: {
        [key: string]: string;
    });
    resetListUniqueIdProperty(): void;
    get listUniqueIdPropertyInput(): {
        [key: string]: string;
    } | undefined;
    private _locks?;
    get locks(): string[];
    set locks(value: string[]);
    resetLocks(): void;
    get locksInput(): string[] | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _output;
    get output(): cdktn.AnyMap;
    private _parentId?;
    get parentId(): string;
    set parentId(value: string);
    resetParentId(): void;
    get parentIdInput(): string | undefined;
    private _readHeaders?;
    get readHeaders(): {
        [key: string]: string;
    };
    set readHeaders(value: {
        [key: string]: string;
    });
    resetReadHeaders(): void;
    get readHeadersInput(): {
        [key: string]: string;
    } | undefined;
    private _readOverride;
    get readOverride(): UpdateResourceReadOverrideOutputReference;
    putReadOverride(value: UpdateResourceReadOverride): void;
    resetReadOverride(): void;
    get readOverrideInput(): cdktn.IResolvable | UpdateResourceReadOverride | undefined;
    private _readQueryParameters?;
    get readQueryParameters(): {
        [key: string]: string[];
    } | cdktn.IResolvable;
    set readQueryParameters(value: {
        [key: string]: string[];
    } | cdktn.IResolvable);
    resetReadQueryParameters(): void;
    get readQueryParametersInput(): cdktn.IResolvable | {
        [key: string]: string[];
    } | undefined;
    private _replaceTriggersExternalValues?;
    get replaceTriggersExternalValues(): {
        [key: string]: any;
    };
    set replaceTriggersExternalValues(value: {
        [key: string]: any;
    });
    resetReplaceTriggersExternalValues(): void;
    get replaceTriggersExternalValuesInput(): {
        [key: string]: any;
    } | undefined;
    private _resourceId?;
    get resourceId(): string;
    set resourceId(value: string);
    resetResourceId(): void;
    get resourceIdInput(): string | undefined;
    private _responseExportValues?;
    get responseExportValues(): {
        [key: string]: any;
    };
    set responseExportValues(value: {
        [key: string]: any;
    });
    resetResponseExportValues(): void;
    get responseExportValuesInput(): {
        [key: string]: any;
    } | undefined;
    private _retry;
    get retry(): UpdateResourceRetryOutputReference;
    putRetry(value: UpdateResourceRetry): void;
    resetRetry(): void;
    get retryInput(): cdktn.IResolvable | UpdateResourceRetry | undefined;
    private _sensitiveBody?;
    /**
    * @deprecated Write-only: the provider never returns this value; reading it always yields null by protocol contract. The getter remains for compatibility and will be removed in a future prebuilt-provider major.
    */
    get sensitiveBody(): {
        [key: string]: any;
    };
    set sensitiveBody(value: {
        [key: string]: any;
    });
    resetSensitiveBody(): void;
    get sensitiveBodyInput(): {
        [key: string]: any;
    } | undefined;
    private _sensitiveBodyVersion?;
    get sensitiveBodyVersion(): {
        [key: string]: string;
    };
    set sensitiveBodyVersion(value: {
        [key: string]: string;
    });
    resetSensitiveBodyVersion(): void;
    get sensitiveBodyVersionInput(): {
        [key: string]: string;
    } | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    get typeInput(): string | undefined;
    private _updateHeaders?;
    get updateHeaders(): {
        [key: string]: string;
    };
    set updateHeaders(value: {
        [key: string]: string;
    });
    resetUpdateHeaders(): void;
    get updateHeadersInput(): {
        [key: string]: string;
    } | undefined;
    private _updateQueryParameters?;
    get updateQueryParameters(): {
        [key: string]: string[];
    } | cdktn.IResolvable;
    set updateQueryParameters(value: {
        [key: string]: string[];
    } | cdktn.IResolvable);
    resetUpdateQueryParameters(): void;
    get updateQueryParametersInput(): cdktn.IResolvable | {
        [key: string]: string[];
    } | undefined;
    private _timeouts;
    get timeouts(): UpdateResourceTimeoutsOutputReference;
    putTimeouts(value: UpdateResourceTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | UpdateResourceTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
