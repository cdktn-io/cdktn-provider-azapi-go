/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataAzapiClientConfigConfig extends cdktn.TerraformMetaArguments {
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/azure/azapi/2.13.0/docs/data-sources/client_config#timeouts DataAzapiClientConfig#timeouts}
    */
    readonly timeouts?: DataAzapiClientConfigTimeouts;
}
export interface DataAzapiClientConfigTimeouts {
    /**
    * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/azure/azapi/2.13.0/docs/data-sources/client_config#read DataAzapiClientConfig#read}
    */
    readonly read?: string;
}
export declare function dataAzapiClientConfigTimeoutsToTerraform(struct?: DataAzapiClientConfigTimeouts | cdktn.IResolvable): any;
export declare function dataAzapiClientConfigTimeoutsToHclTerraform(struct?: DataAzapiClientConfigTimeouts | cdktn.IResolvable): any;
export declare class DataAzapiClientConfigTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataAzapiClientConfigTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: DataAzapiClientConfigTimeouts | cdktn.IResolvable | undefined);
    private _read?;
    get read(): string;
    set read(value: string);
    resetRead(): void;
    get readInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/azure/azapi/2.13.0/docs/data-sources/client_config azapi_client_config}
*/
export declare class DataAzapiClientConfig extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "azapi_client_config";
    /**
    * Generates CDKTN code for importing a DataAzapiClientConfig resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataAzapiClientConfig to import
    * @param importFromId The id of the existing DataAzapiClientConfig that should be imported. Refer to the {@link https://registry.terraform.io/providers/azure/azapi/2.13.0/docs/data-sources/client_config#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataAzapiClientConfig to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/azure/azapi/2.13.0/docs/data-sources/client_config azapi_client_config} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataAzapiClientConfigConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataAzapiClientConfigConfig);
    get id(): string;
    get objectId(): string;
    get subscriptionId(): string;
    get subscriptionResourceId(): string;
    get tenantId(): string;
    private _timeouts;
    get timeouts(): DataAzapiClientConfigTimeoutsOutputReference;
    putTimeouts(value: DataAzapiClientConfigTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | DataAzapiClientConfigTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
