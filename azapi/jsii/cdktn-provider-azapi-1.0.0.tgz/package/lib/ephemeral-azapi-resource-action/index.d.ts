/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface EphemeralAzapiResourceActionConfig extends cdktn.TerraformEphemeralMetaArguments {
    /**
    * The name of the resource action. It's also possible to make HTTP requests towards the resource ID if leave this field empty.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/azure/azapi/2.13.0/docs/ephemeral-resources/resource_action#action EphemeralAzapiResourceAction#action}
    */
    readonly action?: string;
    /**
    * A dynamic attribute that contains the request body.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/azure/azapi/2.13.0/docs/ephemeral-resources/resource_action#body EphemeralAzapiResourceAction#body}
    */
    readonly body?: {
        [key: string]: any;
    };
    /**
    * A map of headers to include in the request.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/azure/azapi/2.13.0/docs/ephemeral-resources/resource_action#headers EphemeralAzapiResourceAction#headers}
    */
    readonly headers?: {
        [key: string]: string;
    };
    /**
    * A list of ARM resource IDs which are used to avoid create/modify/delete azapi resources at the same time.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/azure/azapi/2.13.0/docs/ephemeral-resources/resource_action#locks EphemeralAzapiResourceAction#locks}
    */
    readonly locks?: string[];
    /**
    * Specifies the HTTP method of the azure resource action. Defaults to `POST`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/azure/azapi/2.13.0/docs/ephemeral-resources/resource_action#method EphemeralAzapiResourceAction#method}
    */
    readonly method?: string;
    /**
    * A map of query parameters to include in the request.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/azure/azapi/2.13.0/docs/ephemeral-resources/resource_action#query_parameters EphemeralAzapiResourceAction#query_parameters}
    */
    readonly queryParameters?: {
        [key: string]: string[];
    } | cdktn.IResolvable;
    /**
    * The ID of an existing Azure source.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/azure/azapi/2.13.0/docs/ephemeral-resources/resource_action#resource_id EphemeralAzapiResourceAction#resource_id}
    */
    readonly resourceId: string;
    /**
    * The attribute can accept either a list or a map.
    *
    * - **List**: A list of paths that need to be exported from the response body. Setting it to `["*"]` will export the full response body. Here's an example. If it sets to `["properties.loginServer", "properties.policies.quarantinePolicy.status"]`, it will set the following HCL object to the computed property output.
    *
    * 	```text
    * 	{
    * 		properties = {
    * 			loginServer = "registry1.azurecr.io"
    * 			policies = {
    * 				quarantinePolicy = {
    * 					status = "disabled"
    * 				}
    * 			}
    * 		}
    * 	}
    * 	```
    *
    * - **Map**: A map where the key is the name for the result and the value is a JMESPath query string to filter the response. Here's an example. If it sets to `{"login_server": "properties.loginServer", "quarantine_status": "properties.policies.quarantinePolicy.status"}`, it will set the following HCL object to the computed property output.
    *
    * 	```text
    * 	{
    * 		"login_server" = "registry1.azurecr.io"
    * 		"quarantine_status" = "disabled"
    * 	}
    * 	```
    *
    * To learn more about JMESPath, visit [JMESPath](https://jmespath.org/).
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/azure/azapi/2.13.0/docs/ephemeral-resources/resource_action#response_export_values EphemeralAzapiResourceAction#response_export_values}
    */
    readonly responseExportValues?: {
        [key: string]: any;
    };
    /**
    * The retry object supports the following attributes:
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/azure/azapi/2.13.0/docs/ephemeral-resources/resource_action#retry EphemeralAzapiResourceAction#retry}
    */
    readonly retry?: EphemeralAzapiResourceActionRetry;
    /**
    * A dynamic attribute that contains the write-only properties of the request body. This will be merge-patched to the body to construct the actual request body. If a property is defined in both `body` and `sensitive_body`, the `sensitive_body` value takes precedence.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/azure/azapi/2.13.0/docs/ephemeral-resources/resource_action#sensitive_body EphemeralAzapiResourceAction#sensitive_body}
    */
    readonly sensitiveBody?: {
        [key: string]: any;
    };
    /**
    * In a format like `<resource-type>@<api-version>`. `<resource-type>` is the Azure resource type, for example, `Microsoft.Storage/storageAccounts`. `<api-version>` is version of the API used to manage this azure resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/azure/azapi/2.13.0/docs/ephemeral-resources/resource_action#type EphemeralAzapiResourceAction#type}
    */
    readonly type: string;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/azure/azapi/2.13.0/docs/ephemeral-resources/resource_action#timeouts EphemeralAzapiResourceAction#timeouts}
    */
    readonly timeouts?: EphemeralAzapiResourceActionTimeouts;
}
export interface EphemeralAzapiResourceActionRetry {
    /**
    * A list of regular expressions to match against error messages. If any of the regular expressions match, the request will be retried.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/azure/azapi/2.13.0/docs/ephemeral-resources/resource_action#error_message_regex EphemeralAzapiResourceAction#error_message_regex}
    */
    readonly errorMessageRegex: string[];
    /**
    * The base number of seconds to wait between retries.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/azure/azapi/2.13.0/docs/ephemeral-resources/resource_action#interval_seconds EphemeralAzapiResourceAction#interval_seconds}
    */
    readonly intervalSeconds?: number;
    /**
    * The maximum number of seconds to wait between retries.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/azure/azapi/2.13.0/docs/ephemeral-resources/resource_action#max_interval_seconds EphemeralAzapiResourceAction#max_interval_seconds}
    */
    readonly maxIntervalSeconds?: number;
    /**
    * The multiplier to apply to the interval between retries.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/azure/azapi/2.13.0/docs/ephemeral-resources/resource_action#multiplier EphemeralAzapiResourceAction#multiplier}
    */
    readonly multiplier?: number;
    /**
    * The randomization factor to apply to the interval between retries. The formula for the randomized interval is: `RetryInterval * (random value in range [1 - RandomizationFactor, 1 + RandomizationFactor])`. Therefore set to zero `0.0` for no randomization.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/azure/azapi/2.13.0/docs/ephemeral-resources/resource_action#randomization_factor EphemeralAzapiResourceAction#randomization_factor}
    */
    readonly randomizationFactor?: number;
}
export declare function ephemeralAzapiResourceActionRetryToTerraform(struct?: EphemeralAzapiResourceActionRetry | cdktn.IResolvable): any;
export declare function ephemeralAzapiResourceActionRetryToHclTerraform(struct?: EphemeralAzapiResourceActionRetry | cdktn.IResolvable): any;
export declare class EphemeralAzapiResourceActionRetryOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): EphemeralAzapiResourceActionRetry | cdktn.IResolvable | undefined;
    set internalValue(value: EphemeralAzapiResourceActionRetry | cdktn.IResolvable | undefined);
    private _errorMessageRegex?;
    get errorMessageRegex(): string[];
    set errorMessageRegex(value: string[]);
    get errorMessageRegexInput(): string[] | undefined;
    private _intervalSeconds?;
    get intervalSeconds(): number;
    set intervalSeconds(value: number);
    resetIntervalSeconds(): void;
    get intervalSecondsInput(): number | undefined;
    private _maxIntervalSeconds?;
    get maxIntervalSeconds(): number;
    set maxIntervalSeconds(value: number);
    resetMaxIntervalSeconds(): void;
    get maxIntervalSecondsInput(): number | undefined;
    private _multiplier?;
    get multiplier(): number;
    set multiplier(value: number);
    resetMultiplier(): void;
    get multiplierInput(): number | undefined;
    private _randomizationFactor?;
    get randomizationFactor(): number;
    set randomizationFactor(value: number);
    resetRandomizationFactor(): void;
    get randomizationFactorInput(): number | undefined;
}
export interface EphemeralAzapiResourceActionTimeouts {
    /**
    * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/azure/azapi/2.13.0/docs/ephemeral-resources/resource_action#open EphemeralAzapiResourceAction#open}
    */
    readonly open?: string;
}
export declare function ephemeralAzapiResourceActionTimeoutsToTerraform(struct?: EphemeralAzapiResourceActionTimeouts | cdktn.IResolvable): any;
export declare function ephemeralAzapiResourceActionTimeoutsToHclTerraform(struct?: EphemeralAzapiResourceActionTimeouts | cdktn.IResolvable): any;
export declare class EphemeralAzapiResourceActionTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): EphemeralAzapiResourceActionTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: EphemeralAzapiResourceActionTimeouts | cdktn.IResolvable | undefined);
    private _open?;
    get open(): string;
    set open(value: string);
    resetOpen(): void;
    get openInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/azure/azapi/2.13.0/docs/ephemeral-resources/resource_action azapi_resource_action}
*/
export declare class EphemeralAzapiResourceAction extends cdktn.TerraformEphemeralResource {
    static readonly tfResourceType = "azapi_resource_action";
    /**
    * Create a new {@link https://registry.terraform.io/providers/azure/azapi/2.13.0/docs/ephemeral-resources/resource_action azapi_resource_action} Ephemeral Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options EphemeralAzapiResourceActionConfig
    */
    constructor(scope: Construct, id: string, config: EphemeralAzapiResourceActionConfig);
    private _action?;
    get action(): string;
    set action(value: string);
    resetAction(): void;
    get actionInput(): string | undefined;
    private _body?;
    get body(): {
        [key: string]: any;
    };
    set body(value: {
        [key: string]: any;
    });
    resetBody(): void;
    get bodyInput(): {
        [key: string]: any;
    } | undefined;
    private _headers?;
    get headers(): {
        [key: string]: string;
    };
    set headers(value: {
        [key: string]: string;
    });
    resetHeaders(): void;
    get headersInput(): {
        [key: string]: string;
    } | undefined;
    get id(): string;
    private _locks?;
    get locks(): string[];
    set locks(value: string[]);
    resetLocks(): void;
    get locksInput(): string[] | undefined;
    private _method?;
    get method(): string;
    set method(value: string);
    resetMethod(): void;
    get methodInput(): string | undefined;
    private _output;
    get output(): cdktn.AnyMap;
    private _queryParameters?;
    get queryParameters(): {
        [key: string]: string[];
    } | cdktn.IResolvable;
    set queryParameters(value: {
        [key: string]: string[];
    } | cdktn.IResolvable);
    resetQueryParameters(): void;
    get queryParametersInput(): cdktn.IResolvable | {
        [key: string]: string[];
    } | undefined;
    private _resourceId?;
    get resourceId(): string;
    set resourceId(value: string);
    get resourceIdInput(): string | undefined;
    private _responseExportValues?;
    get responseExportValues(): {
        [key: string]: any;
    };
    set responseExportValues(value: {
        [key: string]: any;
    });
    resetResponseExportValues(): void;
    get responseExportValuesInput(): {
        [key: string]: any;
    } | undefined;
    private _retry;
    get retry(): EphemeralAzapiResourceActionRetryOutputReference;
    putRetry(value: EphemeralAzapiResourceActionRetry): void;
    resetRetry(): void;
    get retryInput(): cdktn.IResolvable | EphemeralAzapiResourceActionRetry | undefined;
    private _sensitiveBody?;
    get sensitiveBody(): {
        [key: string]: any;
    };
    set sensitiveBody(value: {
        [key: string]: any;
    });
    resetSensitiveBody(): void;
    get sensitiveBodyInput(): {
        [key: string]: any;
    } | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    get typeInput(): string | undefined;
    private _timeouts;
    get timeouts(): EphemeralAzapiResourceActionTimeoutsOutputReference;
    putTimeouts(value: EphemeralAzapiResourceActionTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | EphemeralAzapiResourceActionTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
