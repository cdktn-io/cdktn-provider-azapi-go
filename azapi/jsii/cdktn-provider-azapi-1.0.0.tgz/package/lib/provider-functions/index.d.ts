/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import * as cdktn from 'cdktn';
/**
* Provider-defined functions of the azapi provider.
*/
export declare class AzapiProviderFunctions {
    private readonly providerLocalName;
    /**
    * @param providerLocalName The local name of the provider in required_providers; defaults to the registry short name. Override when the provider is declared under a different local name — aliases do not change the namespace, local names do.
    */
    constructor(providerLocalName: string);
    /**
    * This function constructs an Azure resource ID given the parent ID, resource type, and resource name. It is useful for creating resource IDs for top-level and nested resources within a specific scope.
    * @param {string} parentId - The parent ID of the Azure resource.
    * @param {string} resourceType - The resource type of the Azure resource.
    * @param {string} name - The name of the Azure resource.
    * @returns {string}
    */
    buildResourceId(parentId: string, resourceType: string, name: string): string;
    /**
    * This function constructs an Azure extension resource ID given the base resource ID, resource type, and additional resource names.
    * @param {string} baseResourceId - The base resource ID of the Azure resource.
    * @param {string} resourceType - The resource type of the Azure resource.
    * @param {Array<string>} resourceNames - The list of resource names to construct the extension resource ID.
    * @returns {string}
    */
    extensionResourceId(baseResourceId: string, resourceType: string, resourceNames: string[]): string;
    /**
    * This function constructs an Azure management group scope resource ID given the management group name, resource type, and resource names.
    * @param {string} managementGroupName - The name of the management group.
    * @param {string} resourceType - The resource type of the Azure resource.
    * @param {Array<string>} resourceNames - The list of resource names to construct the resource ID.
    * @returns {string}
    */
    managementGroupResourceId(managementGroupName: string, resourceType: string, resourceNames: string[]): string;
    /**
    * This function takes an Azure resource ID and a resource type and parses the ID into its individual components such as subscription ID, resource group name, provider namespace, and other parts.
    * @param {string} resourceType - The resource type of the Azure resource.
    * @param {string} resourceId - The resource ID of the Azure resource to parse.
    * @returns {object}
    */
    parseResourceId(resourceType: string, resourceId: string): cdktn.IResolvable;
    /**
    * This function constructs an Azure resource group scope resource ID given the subscription ID, resource group name, resource type, and resource names.
    * @param {string} subscriptionId - The subscription ID of the Azure resource.
    * @param {string} resourceGroupName - The name of the resource group.
    * @param {string} resourceType - The resource type of the Azure resource.
    * @param {Array<string>} resourceNames - The list of resource names to construct the resource ID.
    * @returns {string}
    */
    resourceGroupResourceId(subscriptionId: string, resourceGroupName: string, resourceType: string, resourceNames: string[]): string;
    /**
    * Converts all keys in the input from snake_case to camelCase. Retains the original structure and values.
    * @param {any} input - The input value to convert from snake_case to camelCase. Omit or pass cdktn.Token.nullValue() to render the Terraform null keyword.
    * @returns {any}
    */
    snake2Camel(input?: any): cdktn.IResolvable;
    /**
    * This function constructs an Azure subscription scope resource ID given the subscription ID, resource type, and resource names.
    * @param {string} subscriptionId - The subscription ID of the Azure resource.
    * @param {string} resourceType - The resource type of the Azure resource.
    * @param {Array<string>} resourceNames - The list of resource names to construct the resource ID.
    * @returns {string}
    */
    subscriptionResourceId(subscriptionId: string, resourceType: string, resourceNames: string[]): string;
    /**
    * This function constructs an Azure tenant scope resource ID given the resource type and resource names.
    * @param {string} resourceType - The resource type of the Azure resource.
    * @param {Array<string>} resourceNames - The list of resource names to construct the resource ID.
    * @returns {string}
    */
    tenantResourceId(resourceType: string, resourceNames: string[]): string;
    /**
    * This function constructs an Azure equivalent `uniqueString` value. It is useful for migrating existing resources based on the ARM `uniqueString` function.
    * @param {Array<string>} baseString - The values used in the hash function to create a unique string.
    * @returns {string}
    */
    uniqueString(baseString: string[]): string;
}
