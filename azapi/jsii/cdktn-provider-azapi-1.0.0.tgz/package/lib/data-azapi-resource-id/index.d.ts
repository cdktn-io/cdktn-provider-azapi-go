/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataAzapiResourceIdConfig extends cdktn.TerraformMetaArguments {
    /**
    * The name of the Azure resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/azure/azapi/2.13.0/docs/data-sources/resource_id#name DataAzapiResourceId#name}
    */
    readonly name?: string;
    /**
    * The ID of the azure resource in which this resource is created. It supports different kinds of deployment scope for **top level** resources:
    *
    * - resource group scope: `parent_id` should be the ID of a resource group, it's recommended to manage a resource group by azurerm_resource_group.
    * - management group scope: `parent_id` should be the ID of a management group, it's recommended to manage a management group by azurerm_management_group.
    * - extension scope: `parent_id` should be the ID of the resource you're adding the extension to.
    * - subscription scope: `parent_id` should be like \x60/subscriptions/00000000-0000-0000-0000-000000000000\x60
    * - tenant scope: `parent_id` should be /
    *
    * For child level resources, the `parent_id` should be the ID of its parent resource, for example, subnet resource's `parent_id` is the ID of the vnet.
    *
    * For type `Microsoft.Resources/resourceGroups`, the `parent_id` could be omitted, it defaults to subscription ID specified in provider or the default subscription (You could check the default subscription by azure cli command: `az account show`).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/azure/azapi/2.13.0/docs/data-sources/resource_id#parent_id DataAzapiResourceId#parent_id}
    */
    readonly parentId?: string;
    /**
    * The ID of an existing Azure source.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/azure/azapi/2.13.0/docs/data-sources/resource_id#resource_id DataAzapiResourceId#resource_id}
    */
    readonly resourceId?: string;
    /**
    * In a format like `<resource-type>@<api-version>`. `<resource-type>` is the Azure resource type, for example, `Microsoft.Storage/storageAccounts`. `<api-version>` is version of the API used to manage this azure resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/azure/azapi/2.13.0/docs/data-sources/resource_id#type DataAzapiResourceId#type}
    */
    readonly type: string;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/azure/azapi/2.13.0/docs/data-sources/resource_id#timeouts DataAzapiResourceId#timeouts}
    */
    readonly timeouts?: DataAzapiResourceIdTimeouts;
}
export interface DataAzapiResourceIdTimeouts {
    /**
    * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/azure/azapi/2.13.0/docs/data-sources/resource_id#read DataAzapiResourceId#read}
    */
    readonly read?: string;
}
export declare function dataAzapiResourceIdTimeoutsToTerraform(struct?: DataAzapiResourceIdTimeouts | cdktn.IResolvable): any;
export declare function dataAzapiResourceIdTimeoutsToHclTerraform(struct?: DataAzapiResourceIdTimeouts | cdktn.IResolvable): any;
export declare class DataAzapiResourceIdTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataAzapiResourceIdTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: DataAzapiResourceIdTimeouts | cdktn.IResolvable | undefined);
    private _read?;
    get read(): string;
    set read(value: string);
    resetRead(): void;
    get readInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/azure/azapi/2.13.0/docs/data-sources/resource_id azapi_resource_id}
*/
export declare class DataAzapiResourceId extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "azapi_resource_id";
    /**
    * Generates CDKTN code for importing a DataAzapiResourceId resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataAzapiResourceId to import
    * @param importFromId The id of the existing DataAzapiResourceId that should be imported. Refer to the {@link https://registry.terraform.io/providers/azure/azapi/2.13.0/docs/data-sources/resource_id#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataAzapiResourceId to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/azure/azapi/2.13.0/docs/data-sources/resource_id azapi_resource_id} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataAzapiResourceIdConfig
    */
    constructor(scope: Construct, id: string, config: DataAzapiResourceIdConfig);
    get id(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _parentId?;
    get parentId(): string;
    set parentId(value: string);
    resetParentId(): void;
    get parentIdInput(): string | undefined;
    private _parts;
    get parts(): cdktn.StringMap;
    get providerNamespace(): string;
    get resourceGroupName(): string;
    private _resourceId?;
    get resourceId(): string;
    set resourceId(value: string);
    resetResourceId(): void;
    get resourceIdInput(): string | undefined;
    get subscriptionId(): string;
    private _type?;
    get type(): string;
    set type(value: string);
    get typeInput(): string | undefined;
    private _timeouts;
    get timeouts(): DataAzapiResourceIdTimeoutsOutputReference;
    putTimeouts(value: DataAzapiResourceIdTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | DataAzapiResourceIdTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
