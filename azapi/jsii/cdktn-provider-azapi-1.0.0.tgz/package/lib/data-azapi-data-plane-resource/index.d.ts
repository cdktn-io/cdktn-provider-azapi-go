/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataAzapiDataPlaneResourceConfig extends cdktn.TerraformMetaArguments {
    /**
    * Specifies the name (identifier segment) of the data plane resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/azure/azapi/2.13.0/docs/data-sources/data_plane_resource#name DataAzapiDataPlaneResource#name}
    */
    readonly name?: string;
    /**
    * The ID of the azure resource in which this resource exists.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/azure/azapi/2.13.0/docs/data-sources/data_plane_resource#parent_id DataAzapiDataPlaneResource#parent_id}
    */
    readonly parentId: string;
    /**
    * The attribute can accept either a list or a map.
    *
    * - **List**: A list of paths that need to be exported from the response body. Setting it to `["*"]` will export the full response body. Here's an example. If it sets to `["properties.loginServer", "properties.policies.quarantinePolicy.status"]`, it will set the following HCL object to the computed property output.
    *
    * 	```text
    * 	{
    * 		properties = {
    * 			loginServer = "registry1.azurecr.io"
    * 			policies = {
    * 				quarantinePolicy = {
    * 					status = "disabled"
    * 				}
    * 			}
    * 		}
    * 	}
    * 	```
    *
    * - **Map**: A map where the key is the name for the result and the value is a JMESPath query string to filter the response. Here's an example. If it sets to `{"login_server": "properties.loginServer", "quarantine_status": "properties.policies.quarantinePolicy.status"}`, it will set the following HCL object to the computed property output.
    *
    * 	```text
    * 	{
    * 		"login_server" = "registry1.azurecr.io"
    * 		"quarantine_status" = "disabled"
    * 	}
    * 	```
    *
    * To learn more about JMESPath, visit [JMESPath](https://jmespath.org/).
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/azure/azapi/2.13.0/docs/data-sources/data_plane_resource#response_export_values DataAzapiDataPlaneResource#response_export_values}
    */
    readonly responseExportValues?: {
        [key: string]: any;
    };
    /**
    * The retry object supports the following attributes:
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/azure/azapi/2.13.0/docs/data-sources/data_plane_resource#retry DataAzapiDataPlaneResource#retry}
    */
    readonly retry?: DataAzapiDataPlaneResourceRetry;
    /**
    * In a format like `<resource-type>@<api-version>`. `<resource-type>` is the Azure resource type, for example, `Microsoft.Storage/storageAccounts`. `<api-version>` is version of the API used to manage this azure resource. For a list of supported data plane resource types, see the [Available Resources](https://registry.terraform.io/providers/Azure/azapi/latest/docs/resources/data_plane_resource#available-resources) documentation.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/azure/azapi/2.13.0/docs/data-sources/data_plane_resource#type DataAzapiDataPlaneResource#type}
    */
    readonly type: string;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/azure/azapi/2.13.0/docs/data-sources/data_plane_resource#timeouts DataAzapiDataPlaneResource#timeouts}
    */
    readonly timeouts?: DataAzapiDataPlaneResourceTimeouts;
}
export interface DataAzapiDataPlaneResourceRetry {
    /**
    * A list of regular expressions to match against error messages. If any of the regular expressions match, the request will be retried.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/azure/azapi/2.13.0/docs/data-sources/data_plane_resource#error_message_regex DataAzapiDataPlaneResource#error_message_regex}
    */
    readonly errorMessageRegex: string[];
    /**
    * The base number of seconds to wait between retries.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/azure/azapi/2.13.0/docs/data-sources/data_plane_resource#interval_seconds DataAzapiDataPlaneResource#interval_seconds}
    */
    readonly intervalSeconds?: number;
    /**
    * The maximum number of seconds to wait between retries.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/azure/azapi/2.13.0/docs/data-sources/data_plane_resource#max_interval_seconds DataAzapiDataPlaneResource#max_interval_seconds}
    */
    readonly maxIntervalSeconds?: number;
    /**
    * The multiplier to apply to the interval between retries.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/azure/azapi/2.13.0/docs/data-sources/data_plane_resource#multiplier DataAzapiDataPlaneResource#multiplier}
    */
    readonly multiplier?: number;
    /**
    * The randomization factor to apply to the interval between retries. The formula for the randomized interval is: `RetryInterval * (random value in range [1 - RandomizationFactor, 1 + RandomizationFactor])`. Therefore set to zero `0.0` for no randomization.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/azure/azapi/2.13.0/docs/data-sources/data_plane_resource#randomization_factor DataAzapiDataPlaneResource#randomization_factor}
    */
    readonly randomizationFactor?: number;
}
export declare function dataAzapiDataPlaneResourceRetryToTerraform(struct?: DataAzapiDataPlaneResourceRetry | cdktn.IResolvable): any;
export declare function dataAzapiDataPlaneResourceRetryToHclTerraform(struct?: DataAzapiDataPlaneResourceRetry | cdktn.IResolvable): any;
export declare class DataAzapiDataPlaneResourceRetryOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataAzapiDataPlaneResourceRetry | cdktn.IResolvable | undefined;
    set internalValue(value: DataAzapiDataPlaneResourceRetry | cdktn.IResolvable | undefined);
    private _errorMessageRegex?;
    get errorMessageRegex(): string[];
    set errorMessageRegex(value: string[]);
    get errorMessageRegexInput(): string[] | undefined;
    private _intervalSeconds?;
    get intervalSeconds(): number;
    set intervalSeconds(value: number);
    resetIntervalSeconds(): void;
    get intervalSecondsInput(): number | undefined;
    private _maxIntervalSeconds?;
    get maxIntervalSeconds(): number;
    set maxIntervalSeconds(value: number);
    resetMaxIntervalSeconds(): void;
    get maxIntervalSecondsInput(): number | undefined;
    private _multiplier?;
    get multiplier(): number;
    set multiplier(value: number);
    resetMultiplier(): void;
    get multiplierInput(): number | undefined;
    private _randomizationFactor?;
    get randomizationFactor(): number;
    set randomizationFactor(value: number);
    resetRandomizationFactor(): void;
    get randomizationFactorInput(): number | undefined;
}
export interface DataAzapiDataPlaneResourceTimeouts {
    /**
    * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/azure/azapi/2.13.0/docs/data-sources/data_plane_resource#read DataAzapiDataPlaneResource#read}
    */
    readonly read?: string;
}
export declare function dataAzapiDataPlaneResourceTimeoutsToTerraform(struct?: DataAzapiDataPlaneResourceTimeouts | cdktn.IResolvable): any;
export declare function dataAzapiDataPlaneResourceTimeoutsToHclTerraform(struct?: DataAzapiDataPlaneResourceTimeouts | cdktn.IResolvable): any;
export declare class DataAzapiDataPlaneResourceTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataAzapiDataPlaneResourceTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: DataAzapiDataPlaneResourceTimeouts | cdktn.IResolvable | undefined);
    private _read?;
    get read(): string;
    set read(value: string);
    resetRead(): void;
    get readInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/azure/azapi/2.13.0/docs/data-sources/data_plane_resource azapi_data_plane_resource}
*/
export declare class DataAzapiDataPlaneResource extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "azapi_data_plane_resource";
    /**
    * Generates CDKTN code for importing a DataAzapiDataPlaneResource resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataAzapiDataPlaneResource to import
    * @param importFromId The id of the existing DataAzapiDataPlaneResource that should be imported. Refer to the {@link https://registry.terraform.io/providers/azure/azapi/2.13.0/docs/data-sources/data_plane_resource#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataAzapiDataPlaneResource to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/azure/azapi/2.13.0/docs/data-sources/data_plane_resource azapi_data_plane_resource} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataAzapiDataPlaneResourceConfig
    */
    constructor(scope: Construct, id: string, config: DataAzapiDataPlaneResourceConfig);
    private _body;
    get body(): cdktn.AnyMap;
    get id(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _output;
    get output(): cdktn.AnyMap;
    private _parentId?;
    get parentId(): string;
    set parentId(value: string);
    get parentIdInput(): string | undefined;
    private _responseExportValues?;
    get responseExportValues(): {
        [key: string]: any;
    };
    set responseExportValues(value: {
        [key: string]: any;
    });
    resetResponseExportValues(): void;
    get responseExportValuesInput(): {
        [key: string]: any;
    } | undefined;
    private _retry;
    get retry(): DataAzapiDataPlaneResourceRetryOutputReference;
    putRetry(value: DataAzapiDataPlaneResourceRetry): void;
    resetRetry(): void;
    get retryInput(): cdktn.IResolvable | DataAzapiDataPlaneResourceRetry | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    get typeInput(): string | undefined;
    private _timeouts;
    get timeouts(): DataAzapiDataPlaneResourceTimeoutsOutputReference;
    putTimeouts(value: DataAzapiDataPlaneResourceTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | DataAzapiDataPlaneResourceTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
