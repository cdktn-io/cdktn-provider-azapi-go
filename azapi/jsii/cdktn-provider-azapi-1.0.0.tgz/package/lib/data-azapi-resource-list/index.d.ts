/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataAzapiResourceListConfig extends cdktn.TerraformMetaArguments {
    /**
    * A map of headers to include in the request.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/azure/azapi/2.13.0/docs/data-sources/resource_list#headers DataAzapiResourceList#headers}
    */
    readonly headers?: {
        [key: string]: string;
    };
    /**
    * The ID of the azure resource in which this resource is created. It supports different kinds of deployment scope for **top level** resources:
    *
    * - resource group scope: `parent_id` should be the ID of a resource group, it's recommended to manage a resource group by azurerm_resource_group.
    * - management group scope: `parent_id` should be the ID of a management group, it's recommended to manage a management group by azurerm_management_group.
    * - extension scope: `parent_id` should be the ID of the resource you're adding the extension to.
    * - subscription scope: `parent_id` should be like \x60/subscriptions/00000000-0000-0000-0000-000000000000\x60
    * - tenant scope: `parent_id` should be /
    *
    * For child level resources, the `parent_id` should be the ID of its parent resource, for example, subnet resource's `parent_id` is the ID of the vnet.
    *
    * For type `Microsoft.Resources/resourceGroups`, the `parent_id` could be omitted, it defaults to subscription ID specified in provider or the default subscription (You could check the default subscription by azure cli command: `az account show`).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/azure/azapi/2.13.0/docs/data-sources/resource_list#parent_id DataAzapiResourceList#parent_id}
    */
    readonly parentId: string;
    /**
    * A map of query parameters to include in the request.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/azure/azapi/2.13.0/docs/data-sources/resource_list#query_parameters DataAzapiResourceList#query_parameters}
    */
    readonly queryParameters?: {
        [key: string]: string[];
    } | cdktn.IResolvable;
    /**
    * The attribute can accept either a list or a map.
    *
    * - **List**: A list of paths that need to be exported from the response body. Setting it to `["*"]` will export the full response body. Here's an example. If it sets to `["value"]`, it will set the following HCL object to the computed property output.
    *
    * 	```text
    * 	{
    * 	  "value" = [
    * 		{
    * 		  "id" = "/subscriptions/000000/resourceGroups/demo-rg/providers/Microsoft.Automation/automationAccounts/example"
    * 		  "location" = "eastus2"
    * 		  "name" = "example"
    * 		  "properties" = {
    * 			"creationTime" = "2024-10-11T08:18:38.737+00:00"
    * 			"disableLocalAuth" = false
    * 			"lastModifiedTime" = "2024-10-11T08:18:38.737+00:00"
    * 			"publicNetworkAccess" = true
    * 		  }
    * 		  "tags" = {}
    * 		  "type" = "Microsoft.Automation/AutomationAccounts"
    * 		}
    * 	  ]
    * 	}
    * 	```
    *
    * - **Map**: A map where the key is the name for the result and the value is a JMESPath query string to filter the response. Here's an example. If it sets to `{"values": "value[].{name: name, publicNetworkAccess: properties.publicNetworkAccess}", "names": "value[].name"}`, it will set the following HCL object to the computed property output.
    *
    * 	```text
    * 	{
    * 		"names" = [
    * 			"example",
    * 			"fredaccount01",
    * 		]
    * 		"values" = [
    * 			{
    * 			  "name" = "example"
    * 			  "publicNetworkAccess" = true
    * 			},
    * 			{
    * 			  "name" = "fredaccount01"
    * 			  "publicNetworkAccess" = null
    * 			},
    * 		]
    * 	}
    * 	```
    *
    * To learn more about JMESPath, visit [JMESPath](https://jmespath.org/).
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/azure/azapi/2.13.0/docs/data-sources/resource_list#response_export_values DataAzapiResourceList#response_export_values}
    */
    readonly responseExportValues?: {
        [key: string]: any;
    };
    /**
    * The retry object supports the following attributes:
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/azure/azapi/2.13.0/docs/data-sources/resource_list#retry DataAzapiResourceList#retry}
    */
    readonly retry?: DataAzapiResourceListRetry;
    /**
    * In a format like `<resource-type>@<api-version>`. `<resource-type>` is the Azure resource type, for example, `Microsoft.Storage/storageAccounts`. `<api-version>` is version of the API used to manage this azure resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/azure/azapi/2.13.0/docs/data-sources/resource_list#type DataAzapiResourceList#type}
    */
    readonly type: string;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/azure/azapi/2.13.0/docs/data-sources/resource_list#timeouts DataAzapiResourceList#timeouts}
    */
    readonly timeouts?: DataAzapiResourceListTimeouts;
}
export interface DataAzapiResourceListRetry {
    /**
    * A list of regular expressions to match against error messages. If any of the regular expressions match, the request will be retried.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/azure/azapi/2.13.0/docs/data-sources/resource_list#error_message_regex DataAzapiResourceList#error_message_regex}
    */
    readonly errorMessageRegex: string[];
    /**
    * The base number of seconds to wait between retries.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/azure/azapi/2.13.0/docs/data-sources/resource_list#interval_seconds DataAzapiResourceList#interval_seconds}
    */
    readonly intervalSeconds?: number;
    /**
    * The maximum number of seconds to wait between retries.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/azure/azapi/2.13.0/docs/data-sources/resource_list#max_interval_seconds DataAzapiResourceList#max_interval_seconds}
    */
    readonly maxIntervalSeconds?: number;
    /**
    * The multiplier to apply to the interval between retries.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/azure/azapi/2.13.0/docs/data-sources/resource_list#multiplier DataAzapiResourceList#multiplier}
    */
    readonly multiplier?: number;
    /**
    * The randomization factor to apply to the interval between retries. The formula for the randomized interval is: `RetryInterval * (random value in range [1 - RandomizationFactor, 1 + RandomizationFactor])`. Therefore set to zero `0.0` for no randomization.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/azure/azapi/2.13.0/docs/data-sources/resource_list#randomization_factor DataAzapiResourceList#randomization_factor}
    */
    readonly randomizationFactor?: number;
}
export declare function dataAzapiResourceListRetryToTerraform(struct?: DataAzapiResourceListRetry | cdktn.IResolvable): any;
export declare function dataAzapiResourceListRetryToHclTerraform(struct?: DataAzapiResourceListRetry | cdktn.IResolvable): any;
export declare class DataAzapiResourceListRetryOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataAzapiResourceListRetry | cdktn.IResolvable | undefined;
    set internalValue(value: DataAzapiResourceListRetry | cdktn.IResolvable | undefined);
    private _errorMessageRegex?;
    get errorMessageRegex(): string[];
    set errorMessageRegex(value: string[]);
    get errorMessageRegexInput(): string[] | undefined;
    private _intervalSeconds?;
    get intervalSeconds(): number;
    set intervalSeconds(value: number);
    resetIntervalSeconds(): void;
    get intervalSecondsInput(): number | undefined;
    private _maxIntervalSeconds?;
    get maxIntervalSeconds(): number;
    set maxIntervalSeconds(value: number);
    resetMaxIntervalSeconds(): void;
    get maxIntervalSecondsInput(): number | undefined;
    private _multiplier?;
    get multiplier(): number;
    set multiplier(value: number);
    resetMultiplier(): void;
    get multiplierInput(): number | undefined;
    private _randomizationFactor?;
    get randomizationFactor(): number;
    set randomizationFactor(value: number);
    resetRandomizationFactor(): void;
    get randomizationFactorInput(): number | undefined;
}
export interface DataAzapiResourceListTimeouts {
    /**
    * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/azure/azapi/2.13.0/docs/data-sources/resource_list#read DataAzapiResourceList#read}
    */
    readonly read?: string;
}
export declare function dataAzapiResourceListTimeoutsToTerraform(struct?: DataAzapiResourceListTimeouts | cdktn.IResolvable): any;
export declare function dataAzapiResourceListTimeoutsToHclTerraform(struct?: DataAzapiResourceListTimeouts | cdktn.IResolvable): any;
export declare class DataAzapiResourceListTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataAzapiResourceListTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: DataAzapiResourceListTimeouts | cdktn.IResolvable | undefined);
    private _read?;
    get read(): string;
    set read(value: string);
    resetRead(): void;
    get readInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/azure/azapi/2.13.0/docs/data-sources/resource_list azapi_resource_list}
*/
export declare class DataAzapiResourceList extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "azapi_resource_list";
    /**
    * Generates CDKTN code for importing a DataAzapiResourceList resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataAzapiResourceList to import
    * @param importFromId The id of the existing DataAzapiResourceList that should be imported. Refer to the {@link https://registry.terraform.io/providers/azure/azapi/2.13.0/docs/data-sources/resource_list#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataAzapiResourceList to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/azure/azapi/2.13.0/docs/data-sources/resource_list azapi_resource_list} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataAzapiResourceListConfig
    */
    constructor(scope: Construct, id: string, config: DataAzapiResourceListConfig);
    private _headers?;
    get headers(): {
        [key: string]: string;
    };
    set headers(value: {
        [key: string]: string;
    });
    resetHeaders(): void;
    get headersInput(): {
        [key: string]: string;
    } | undefined;
    get id(): string;
    private _output;
    get output(): cdktn.AnyMap;
    private _parentId?;
    get parentId(): string;
    set parentId(value: string);
    get parentIdInput(): string | undefined;
    private _queryParameters?;
    get queryParameters(): {
        [key: string]: string[];
    } | cdktn.IResolvable;
    set queryParameters(value: {
        [key: string]: string[];
    } | cdktn.IResolvable);
    resetQueryParameters(): void;
    get queryParametersInput(): cdktn.IResolvable | {
        [key: string]: string[];
    } | undefined;
    private _responseExportValues?;
    get responseExportValues(): {
        [key: string]: any;
    };
    set responseExportValues(value: {
        [key: string]: any;
    });
    resetResponseExportValues(): void;
    get responseExportValuesInput(): {
        [key: string]: any;
    } | undefined;
    private _retry;
    get retry(): DataAzapiResourceListRetryOutputReference;
    putRetry(value: DataAzapiResourceListRetry): void;
    resetRetry(): void;
    get retryInput(): cdktn.IResolvable | DataAzapiResourceListRetry | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    get typeInput(): string | undefined;
    private _timeouts;
    get timeouts(): DataAzapiResourceListTimeoutsOutputReference;
    putTimeouts(value: DataAzapiResourceListTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | DataAzapiResourceListTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
