/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
export * as dataPlaneResource from './data-plane-resource/index';
export * as resource from './resource/index';
export * as resourceAction from './resource-action/index';
export * as updateResource from './update-resource/index';
export * as dataAzapiClientConfig from './data-azapi-client-config/index';
export * as dataAzapiDataPlaneResource from './data-azapi-data-plane-resource/index';
export * as dataAzapiResource from './data-azapi-resource/index';
export * as dataAzapiResourceAction from './data-azapi-resource-action/index';
export * as dataAzapiResourceId from './data-azapi-resource-id/index';
export * as dataAzapiResourceList from './data-azapi-resource-list/index';
export * as ephemeralAzapiDataPlaneResource from './ephemeral-azapi-data-plane-resource/index';
export * as ephemeralAzapiResourceAction from './ephemeral-azapi-resource-action/index';
export * as provider from './provider/index';
export * as providerFunctions from './provider-functions/index';
