/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface ResourceConfig extends cdktn.TerraformMetaArguments {
    /**
    * A dynamic attribute that contains the request body.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/azure/azapi/2.13.0/docs/resources/resource#body Resource#body}
    */
    readonly body?: {
        [key: string]: any;
    };
    /**
    * A mapping of headers to be sent with the create request.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/azure/azapi/2.13.0/docs/resources/resource#create_headers Resource#create_headers}
    */
    readonly createHeaders?: {
        [key: string]: string;
    };
    /**
    * A mapping of query parameters to be sent with the create request.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/azure/azapi/2.13.0/docs/resources/resource#create_query_parameters Resource#create_query_parameters}
    */
    readonly createQueryParameters?: {
        [key: string]: string[];
    } | cdktn.IResolvable;
    /**
    * A mapping of headers to be sent with the delete request.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/azure/azapi/2.13.0/docs/resources/resource#delete_headers Resource#delete_headers}
    */
    readonly deleteHeaders?: {
        [key: string]: string;
    };
    /**
    * A mapping of query parameters to be sent with the delete request.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/azure/azapi/2.13.0/docs/resources/resource#delete_query_parameters Resource#delete_query_parameters}
    */
    readonly deleteQueryParameters?: {
        [key: string]: string[];
    } | cdktn.IResolvable;
    /**
    * A list of paths in the resource body whose changes should be ignored. Prefer Terraform's `lifecycle.ignore_changes` when possible. Use this argument only when the paths must be derived from variables or other non-static values. Changes to this argument take effect only after an apply because its value is stored in provider-private state. Paths use dot notation, for example `properties.sku.name`. Individual list items cannot be targeted, ignore the entire list property instead. Configuration changes at an ignored path will not be sent to Azure until that path is removed from this list. This write-only argument requires Terraform 1.11 or later.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/azure/azapi/2.13.0/docs/resources/resource#ignore_body_changes Resource#ignore_body_changes}
    */
    readonly ignoreBodyChanges?: string[];
    /**
    * Whether ignore the casing of the property names in the response body.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/azure/azapi/2.13.0/docs/resources/resource#ignore_casing Resource#ignore_casing}
    */
    readonly ignoreCasing?: boolean | cdktn.IResolvable;
    /**
    * Whether ignore not returned properties like credentials in `body` to suppress plan-diff. It's recommend to enable this option when some sensitive properties are not returned in response body, instead of setting them in `lifecycle.ignore_changes` because it will make the sensitive fields unable to update.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/azure/azapi/2.13.0/docs/resources/resource#ignore_missing_property Resource#ignore_missing_property}
    */
    readonly ignoreMissingProperty?: boolean | cdktn.IResolvable;
    /**
    * When set to `true`, the provider will ignore properties whose values are `null` in the `body`. These properties will not be included in the request body sent to the API, and the difference will not be shown in the plan output.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/azure/azapi/2.13.0/docs/resources/resource#ignore_null_property Resource#ignore_null_property}
    */
    readonly ignoreNullProperty?: boolean | cdktn.IResolvable;
    /**
    * A list of list property paths where items not specified in configuration should be ignored. This is intended for partial list management when combined with `list_unique_id_property` (for example, to avoid perpetual drift from server-side ordering).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/azure/azapi/2.13.0/docs/resources/resource#ignore_other_items_in_list Resource#ignore_other_items_in_list}
    */
    readonly ignoreOtherItemsInList?: string[];
    /**
    * A mapping of list property paths to the field name used as a unique identifier when comparing and merging list items. When not set, list items are matched by a `name` property (if present) or by list ordering. To match using multiple fields, specify a comma-separated list of field names (e.g., `"category, categoryGroup"`).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/azure/azapi/2.13.0/docs/resources/resource#list_unique_id_property Resource#list_unique_id_property}
    */
    readonly listUniqueIdProperty?: {
        [key: string]: string;
    };
    /**
    * The location of the Azure resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/azure/azapi/2.13.0/docs/resources/resource#location Resource#location}
    */
    readonly location?: string;
    /**
    * A list of ARM resource IDs which are used to avoid create/modify/delete azapi resources at the same time.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/azure/azapi/2.13.0/docs/resources/resource#locks Resource#locks}
    */
    readonly locks?: string[];
    /**
    * Specifies the name of the azure resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/azure/azapi/2.13.0/docs/resources/resource#name Resource#name}
    */
    readonly name?: string;
    /**
    * The ID of the azure resource in which this resource is created. It supports different kinds of deployment scope for **top level** resources:
    *
    * - resource group scope: `parent_id` should be the ID of a resource group, it's recommended to manage a resource group by azurerm_resource_group.
    * - management group scope: `parent_id` should be the ID of a management group, it's recommended to manage a management group by azurerm_management_group.
    * - extension scope: `parent_id` should be the ID of the resource you're adding the extension to.
    * - subscription scope: `parent_id` should be like \x60/subscriptions/00000000-0000-0000-0000-000000000000\x60
    * - tenant scope: `parent_id` should be /
    *
    * For child level resources, the `parent_id` should be the ID of its parent resource, for example, subnet resource's `parent_id` is the ID of the vnet.
    *
    * For type `Microsoft.Resources/resourceGroups`, the `parent_id` could be omitted, it defaults to subscription ID specified in provider or the default subscription (You could check the default subscription by azure cli command: `az account show`).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/azure/azapi/2.13.0/docs/resources/resource#parent_id Resource#parent_id}
    */
    readonly parentId?: string;
    /**
    * A mapping of headers to be sent with the read request.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/azure/azapi/2.13.0/docs/resources/resource#read_headers Resource#read_headers}
    */
    readonly readHeaders?: {
        [key: string]: string;
    };
    /**
    * A mapping of query parameters to be sent with the read request.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/azure/azapi/2.13.0/docs/resources/resource#read_query_parameters Resource#read_query_parameters}
    */
    readonly readQueryParameters?: {
        [key: string]: string[];
    } | cdktn.IResolvable;
    /**
    * Will trigger a replace of the resource when the value changes and is not `null`. This can be used by practitioners to force a replace of the resource when certain values change, e.g. changing the SKU of a virtual machine based on the value of variables or locals. The value is a `dynamic`, so practitioners can compose the input however they wish. For a "break glass" set the value to `null` to prevent the plan modifier taking effect.
    * If you have `null` values that you do want to be tracked as affecting the resource replacement, include these inside an object.
    * Advanced use cases are possible and resource replacement can be triggered by values external to the resource, for example when a dependent resource changes.
    *
    * e.g. to replace a resource when either the SKU or os_type attributes change:
    *
    * ```hcl
    * resource "azapi_resource" "example" {
    *   name      = var.name
    *   type      = "Microsoft.Network/publicIPAddresses@2023-11-01"
    *   parent_id = "/subscriptions/00000000-0000-0000-0000-000000000000/resourceGroups/example"
    *   body = {
    *     properties = {
    *       sku   = var.sku
    *       zones = var.zones
    *     }
    *   }
    *
    *   replace_triggers_external_values = [
    *     var.sku,
    *     var.zones,
    *   ]
    * }
    * ```
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/azure/azapi/2.13.0/docs/resources/resource#replace_triggers_external_values Resource#replace_triggers_external_values}
    */
    readonly replaceTriggersExternalValues?: {
        [key: string]: any;
    };
    /**
    * A list of paths in the current Terraform configuration. When the values at these paths change, the resource will be replaced.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/azure/azapi/2.13.0/docs/resources/resource#replace_triggers_refs Resource#replace_triggers_refs}
    */
    readonly replaceTriggersRefs?: string[];
    /**
    * The attribute can accept either a list or a map.
    *
    * - **List**: A list of paths that need to be exported from the response body. Setting it to `["*"]` will export the full response body. Here's an example. If it sets to `["properties.loginServer", "properties.policies.quarantinePolicy.status"]`, it will set the following HCL object to the computed property output.
    *
    * 	```text
    * 	{
    * 		properties = {
    * 			loginServer = "registry1.azurecr.io"
    * 			policies = {
    * 				quarantinePolicy = {
    * 					status = "disabled"
    * 				}
    * 			}
    * 		}
    * 	}
    * 	```
    *
    * - **Map**: A map where the key is the name for the result and the value is a JMESPath query string to filter the response. Here's an example. If it sets to `{"login_server": "properties.loginServer", "quarantine_status": "properties.policies.quarantinePolicy.status"}`, it will set the following HCL object to the computed property output.
    *
    * 	```text
    * 	{
    * 		"login_server" = "registry1.azurecr.io"
    * 		"quarantine_status" = "disabled"
    * 	}
    * 	```
    *
    * To learn more about JMESPath, visit [JMESPath](https://jmespath.org/).
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/azure/azapi/2.13.0/docs/resources/resource#response_export_values Resource#response_export_values}
    */
    readonly responseExportValues?: {
        [key: string]: any;
    };
    /**
    * The retry object supports the following attributes:
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/azure/azapi/2.13.0/docs/resources/resource#retry Resource#retry}
    */
    readonly retry?: ResourceRetry;
    /**
    * Whether enabled the validation on `type` and `body` with embedded schema.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/azure/azapi/2.13.0/docs/resources/resource#schema_validation_enabled Resource#schema_validation_enabled}
    */
    readonly schemaValidationEnabled?: boolean | cdktn.IResolvable;
    /**
    * A dynamic attribute that contains the write-only properties of the request body. This will be merge-patched to the body to construct the actual request body. If a property is defined in both `body` and `sensitive_body`, the `sensitive_body` value takes precedence.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/azure/azapi/2.13.0/docs/resources/resource#sensitive_body Resource#sensitive_body}
    */
    readonly sensitiveBody?: {
        [key: string]: any;
    };
    /**
    * A map where the key is the path to the property in `sensitive_body` and the value is the version of the property. The key is a string in the format of `path.to.property[index].subproperty`, where `index` is the index of the item in an array. When the version is changed, the property will be included in the request body, otherwise it will be omitted from the request body.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/azure/azapi/2.13.0/docs/resources/resource#sensitive_body_version Resource#sensitive_body_version}
    */
    readonly sensitiveBodyVersion?: {
        [key: string]: string;
    };
    /**
    * A mapping of tags which should be assigned to the Azure resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/azure/azapi/2.13.0/docs/resources/resource#tags Resource#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * In a format like `<resource-type>@<api-version>`. `<resource-type>` is the Azure resource type, for example, `Microsoft.Storage/storageAccounts`. `<api-version>` is version of the API used to manage this azure resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/azure/azapi/2.13.0/docs/resources/resource#type Resource#type}
    */
    readonly type: string;
    /**
    * A mapping of headers to be sent with the update request.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/azure/azapi/2.13.0/docs/resources/resource#update_headers Resource#update_headers}
    */
    readonly updateHeaders?: {
        [key: string]: string;
    };
    /**
    * A mapping of query parameters to be sent with the update request.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/azure/azapi/2.13.0/docs/resources/resource#update_query_parameters Resource#update_query_parameters}
    */
    readonly updateQueryParameters?: {
        [key: string]: string[];
    } | cdktn.IResolvable;
    /**
    * identity block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/azure/azapi/2.13.0/docs/resources/resource#identity Resource#identity}
    */
    readonly identity?: ResourceIdentity[] | cdktn.IResolvable;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/azure/azapi/2.13.0/docs/resources/resource#timeouts Resource#timeouts}
    */
    readonly timeouts?: ResourceTimeouts;
}
export interface ResourceRetry {
    /**
    * A list of regular expressions to match against error messages. If any of the regular expressions match, the request will be retried.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/azure/azapi/2.13.0/docs/resources/resource#error_message_regex Resource#error_message_regex}
    */
    readonly errorMessageRegex: string[];
    /**
    * The base number of seconds to wait between retries.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/azure/azapi/2.13.0/docs/resources/resource#interval_seconds Resource#interval_seconds}
    */
    readonly intervalSeconds?: number;
    /**
    * The maximum number of seconds to wait between retries.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/azure/azapi/2.13.0/docs/resources/resource#max_interval_seconds Resource#max_interval_seconds}
    */
    readonly maxIntervalSeconds?: number;
    /**
    * The multiplier to apply to the interval between retries.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/azure/azapi/2.13.0/docs/resources/resource#multiplier Resource#multiplier}
    */
    readonly multiplier?: number;
    /**
    * The randomization factor to apply to the interval between retries. The formula for the randomized interval is: `RetryInterval * (random value in range [1 - RandomizationFactor, 1 + RandomizationFactor])`. Therefore set to zero `0.0` for no randomization.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/azure/azapi/2.13.0/docs/resources/resource#randomization_factor Resource#randomization_factor}
    */
    readonly randomizationFactor?: number;
}
export declare function resourceRetryToTerraform(struct?: ResourceRetry | cdktn.IResolvable): any;
export declare function resourceRetryToHclTerraform(struct?: ResourceRetry | cdktn.IResolvable): any;
export declare class ResourceRetryOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ResourceRetry | cdktn.IResolvable | undefined;
    set internalValue(value: ResourceRetry | cdktn.IResolvable | undefined);
    private _errorMessageRegex?;
    get errorMessageRegex(): string[];
    set errorMessageRegex(value: string[]);
    get errorMessageRegexInput(): string[] | undefined;
    private _intervalSeconds?;
    get intervalSeconds(): number;
    set intervalSeconds(value: number);
    resetIntervalSeconds(): void;
    get intervalSecondsInput(): number | undefined;
    private _maxIntervalSeconds?;
    get maxIntervalSeconds(): number;
    set maxIntervalSeconds(value: number);
    resetMaxIntervalSeconds(): void;
    get maxIntervalSecondsInput(): number | undefined;
    private _multiplier?;
    get multiplier(): number;
    set multiplier(value: number);
    resetMultiplier(): void;
    get multiplierInput(): number | undefined;
    private _randomizationFactor?;
    get randomizationFactor(): number;
    set randomizationFactor(value: number);
    resetRandomizationFactor(): void;
    get randomizationFactorInput(): number | undefined;
}
export interface ResourceIdentity {
    /**
    * A list of User Managed Identity ID's which should be assigned to the azure resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/azure/azapi/2.13.0/docs/resources/resource#identity_ids Resource#identity_ids}
    */
    readonly identityIds?: string[];
    /**
    * The Type of Identity which should be used for this azure resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/azure/azapi/2.13.0/docs/resources/resource#type Resource#type}
    */
    readonly type: string;
}
export declare function resourceIdentityToTerraform(struct?: ResourceIdentity | cdktn.IResolvable): any;
export declare function resourceIdentityToHclTerraform(struct?: ResourceIdentity | cdktn.IResolvable): any;
export declare class ResourceIdentityOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ResourceIdentity | cdktn.IResolvable | undefined;
    set internalValue(value: ResourceIdentity | cdktn.IResolvable | undefined);
    private _identityIds?;
    get identityIds(): string[];
    set identityIds(value: string[]);
    resetIdentityIds(): void;
    get identityIdsInput(): string[] | undefined;
    get principalId(): string;
    get tenantId(): string;
    private _type?;
    get type(): string;
    set type(value: string);
    get typeInput(): string | undefined;
}
export declare class ResourceIdentityList extends cdktn.ComplexList {
    internalValue?: ResourceIdentity[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ResourceIdentityOutputReference;
}
export interface ResourceTimeouts {
    /**
    * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/azure/azapi/2.13.0/docs/resources/resource#create Resource#create}
    */
    readonly create?: string;
    /**
    * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours). Setting a timeout for a Delete operation is only applicable if changes are saved into state before the destroy operation occurs.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/azure/azapi/2.13.0/docs/resources/resource#delete Resource#delete}
    */
    readonly delete?: string;
    /**
    * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours). Read operations occur during any refresh or planning operation when refresh is enabled.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/azure/azapi/2.13.0/docs/resources/resource#read Resource#read}
    */
    readonly read?: string;
    /**
    * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/azure/azapi/2.13.0/docs/resources/resource#update Resource#update}
    */
    readonly update?: string;
}
export declare function resourceTimeoutsToTerraform(struct?: ResourceTimeouts | cdktn.IResolvable): any;
export declare function resourceTimeoutsToHclTerraform(struct?: ResourceTimeouts | cdktn.IResolvable): any;
export declare class ResourceTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ResourceTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: ResourceTimeouts | cdktn.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
    private _read?;
    get read(): string;
    set read(value: string);
    resetRead(): void;
    get readInput(): string | undefined;
    private _update?;
    get update(): string;
    set update(value: string);
    resetUpdate(): void;
    get updateInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/azure/azapi/2.13.0/docs/resources/resource azapi_resource}
*/
export declare class Resource extends cdktn.TerraformResource {
    static readonly tfResourceType = "azapi_resource";
    /**
    * Generates CDKTN code for importing a Resource resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the Resource to import
    * @param importFromId The id of the existing Resource that should be imported. Refer to the {@link https://registry.terraform.io/providers/azure/azapi/2.13.0/docs/resources/resource#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the Resource to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/azure/azapi/2.13.0/docs/resources/resource azapi_resource} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options ResourceConfig
    */
    constructor(scope: Construct, id: string, config: ResourceConfig);
    private _body?;
    get body(): {
        [key: string]: any;
    };
    set body(value: {
        [key: string]: any;
    });
    resetBody(): void;
    get bodyInput(): {
        [key: string]: any;
    } | undefined;
    private _createHeaders?;
    get createHeaders(): {
        [key: string]: string;
    };
    set createHeaders(value: {
        [key: string]: string;
    });
    resetCreateHeaders(): void;
    get createHeadersInput(): {
        [key: string]: string;
    } | undefined;
    private _createQueryParameters?;
    get createQueryParameters(): {
        [key: string]: string[];
    } | cdktn.IResolvable;
    set createQueryParameters(value: {
        [key: string]: string[];
    } | cdktn.IResolvable);
    resetCreateQueryParameters(): void;
    get createQueryParametersInput(): cdktn.IResolvable | {
        [key: string]: string[];
    } | undefined;
    private _deleteHeaders?;
    get deleteHeaders(): {
        [key: string]: string;
    };
    set deleteHeaders(value: {
        [key: string]: string;
    });
    resetDeleteHeaders(): void;
    get deleteHeadersInput(): {
        [key: string]: string;
    } | undefined;
    private _deleteQueryParameters?;
    get deleteQueryParameters(): {
        [key: string]: string[];
    } | cdktn.IResolvable;
    set deleteQueryParameters(value: {
        [key: string]: string[];
    } | cdktn.IResolvable);
    resetDeleteQueryParameters(): void;
    get deleteQueryParametersInput(): cdktn.IResolvable | {
        [key: string]: string[];
    } | undefined;
    get id(): string;
    private _ignoreBodyChanges?;
    /**
    * @deprecated Write-only: the provider never returns this value; reading it always yields null by protocol contract. The getter remains for compatibility and will be removed in a future prebuilt-provider major.
    */
    get ignoreBodyChanges(): string[];
    set ignoreBodyChanges(value: string[]);
    resetIgnoreBodyChanges(): void;
    get ignoreBodyChangesInput(): string[] | undefined;
    private _ignoreCasing?;
    get ignoreCasing(): boolean | cdktn.IResolvable;
    set ignoreCasing(value: boolean | cdktn.IResolvable);
    resetIgnoreCasing(): void;
    get ignoreCasingInput(): boolean | cdktn.IResolvable | undefined;
    private _ignoreMissingProperty?;
    get ignoreMissingProperty(): boolean | cdktn.IResolvable;
    set ignoreMissingProperty(value: boolean | cdktn.IResolvable);
    resetIgnoreMissingProperty(): void;
    get ignoreMissingPropertyInput(): boolean | cdktn.IResolvable | undefined;
    private _ignoreNullProperty?;
    get ignoreNullProperty(): boolean | cdktn.IResolvable;
    set ignoreNullProperty(value: boolean | cdktn.IResolvable);
    resetIgnoreNullProperty(): void;
    get ignoreNullPropertyInput(): boolean | cdktn.IResolvable | undefined;
    private _ignoreOtherItemsInList?;
    get ignoreOtherItemsInList(): string[];
    set ignoreOtherItemsInList(value: string[]);
    resetIgnoreOtherItemsInList(): void;
    get ignoreOtherItemsInListInput(): string[] | undefined;
    private _listUniqueIdProperty?;
    get listUniqueIdProperty(): {
        [key: string]: string;
    };
    set listUniqueIdProperty(value: {
        [key: string]: string;
    });
    resetListUniqueIdProperty(): void;
    get listUniqueIdPropertyInput(): {
        [key: string]: string;
    } | undefined;
    private _location?;
    get location(): string;
    set location(value: string);
    resetLocation(): void;
    get locationInput(): string | undefined;
    private _locks?;
    get locks(): string[];
    set locks(value: string[]);
    resetLocks(): void;
    get locksInput(): string[] | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _output;
    get output(): cdktn.AnyMap;
    private _parentId?;
    get parentId(): string;
    set parentId(value: string);
    resetParentId(): void;
    get parentIdInput(): string | undefined;
    private _readHeaders?;
    get readHeaders(): {
        [key: string]: string;
    };
    set readHeaders(value: {
        [key: string]: string;
    });
    resetReadHeaders(): void;
    get readHeadersInput(): {
        [key: string]: string;
    } | undefined;
    private _readQueryParameters?;
    get readQueryParameters(): {
        [key: string]: string[];
    } | cdktn.IResolvable;
    set readQueryParameters(value: {
        [key: string]: string[];
    } | cdktn.IResolvable);
    resetReadQueryParameters(): void;
    get readQueryParametersInput(): cdktn.IResolvable | {
        [key: string]: string[];
    } | undefined;
    private _replaceTriggersExternalValues?;
    get replaceTriggersExternalValues(): {
        [key: string]: any;
    };
    set replaceTriggersExternalValues(value: {
        [key: string]: any;
    });
    resetReplaceTriggersExternalValues(): void;
    get replaceTriggersExternalValuesInput(): {
        [key: string]: any;
    } | undefined;
    private _replaceTriggersRefs?;
    get replaceTriggersRefs(): string[];
    set replaceTriggersRefs(value: string[]);
    resetReplaceTriggersRefs(): void;
    get replaceTriggersRefsInput(): string[] | undefined;
    private _responseExportValues?;
    get responseExportValues(): {
        [key: string]: any;
    };
    set responseExportValues(value: {
        [key: string]: any;
    });
    resetResponseExportValues(): void;
    get responseExportValuesInput(): {
        [key: string]: any;
    } | undefined;
    private _retry;
    get retry(): ResourceRetryOutputReference;
    putRetry(value: ResourceRetry): void;
    resetRetry(): void;
    get retryInput(): cdktn.IResolvable | ResourceRetry | undefined;
    private _schemaValidationEnabled?;
    get schemaValidationEnabled(): boolean | cdktn.IResolvable;
    set schemaValidationEnabled(value: boolean | cdktn.IResolvable);
    resetSchemaValidationEnabled(): void;
    get schemaValidationEnabledInput(): boolean | cdktn.IResolvable | undefined;
    private _sensitiveBody?;
    /**
    * @deprecated Write-only: the provider never returns this value; reading it always yields null by protocol contract. The getter remains for compatibility and will be removed in a future prebuilt-provider major.
    */
    get sensitiveBody(): {
        [key: string]: any;
    };
    set sensitiveBody(value: {
        [key: string]: any;
    });
    resetSensitiveBody(): void;
    get sensitiveBodyInput(): {
        [key: string]: any;
    } | undefined;
    private _sensitiveBodyVersion?;
    get sensitiveBodyVersion(): {
        [key: string]: string;
    };
    set sensitiveBodyVersion(value: {
        [key: string]: string;
    });
    resetSensitiveBodyVersion(): void;
    get sensitiveBodyVersionInput(): {
        [key: string]: string;
    } | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    get typeInput(): string | undefined;
    private _updateHeaders?;
    get updateHeaders(): {
        [key: string]: string;
    };
    set updateHeaders(value: {
        [key: string]: string;
    });
    resetUpdateHeaders(): void;
    get updateHeadersInput(): {
        [key: string]: string;
    } | undefined;
    private _updateQueryParameters?;
    get updateQueryParameters(): {
        [key: string]: string[];
    } | cdktn.IResolvable;
    set updateQueryParameters(value: {
        [key: string]: string[];
    } | cdktn.IResolvable);
    resetUpdateQueryParameters(): void;
    get updateQueryParametersInput(): cdktn.IResolvable | {
        [key: string]: string[];
    } | undefined;
    private _identity;
    get identity(): ResourceIdentityList;
    putIdentity(value: ResourceIdentity[] | cdktn.IResolvable): void;
    resetIdentity(): void;
    get identityInput(): cdktn.IResolvable | ResourceIdentity[] | undefined;
    private _timeouts;
    get timeouts(): ResourceTimeoutsOutputReference;
    putTimeouts(value: ResourceTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | ResourceTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
