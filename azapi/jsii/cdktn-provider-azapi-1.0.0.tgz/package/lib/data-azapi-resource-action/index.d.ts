/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataAzapiResourceActionConfig extends cdktn.TerraformMetaArguments {
    /**
    * The name of the resource action. It's also possible to make HTTP requests towards the resource ID if leave this field empty.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/azure/azapi/2.13.0/docs/data-sources/resource_action#action DataAzapiResourceAction#action}
    */
    readonly action?: string;
    /**
    * The body attribute is a dynamic attribute that only allows users to specify the resource body as an HCL object.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/azure/azapi/2.13.0/docs/data-sources/resource_action#body DataAzapiResourceAction#body}
    */
    readonly body?: {
        [key: string]: any;
    };
    /**
    * A map of headers to include in the request.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/azure/azapi/2.13.0/docs/data-sources/resource_action#headers DataAzapiResourceAction#headers}
    */
    readonly headers?: {
        [key: string]: string;
    };
    /**
    * The HTTP method to use when performing the action. Defaults to `POST`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/azure/azapi/2.13.0/docs/data-sources/resource_action#method DataAzapiResourceAction#method}
    */
    readonly method?: string;
    /**
    * A map of query parameters to include in the request.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/azure/azapi/2.13.0/docs/data-sources/resource_action#query_parameters DataAzapiResourceAction#query_parameters}
    */
    readonly queryParameters?: {
        [key: string]: string[];
    } | cdktn.IResolvable;
    /**
    * The ID of the Azure resource to perform the action on.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/azure/azapi/2.13.0/docs/data-sources/resource_action#resource_id DataAzapiResourceAction#resource_id}
    */
    readonly resourceId?: string;
    /**
    * The attribute can accept either a list or a map.
    *
    * - **List**: A list of paths that need to be exported from the response body. Setting it to `["*"]` will export the full response body. Here's an example. If it sets to `["properties.loginServer", "properties.policies.quarantinePolicy.status"]`, it will set the following HCL object to the computed property output.
    *
    * 	```text
    * 	{
    * 		properties = {
    * 			loginServer = "registry1.azurecr.io"
    * 			policies = {
    * 				quarantinePolicy = {
    * 					status = "disabled"
    * 				}
    * 			}
    * 		}
    * 	}
    * 	```
    *
    * - **Map**: A map where the key is the name for the result and the value is a JMESPath query string to filter the response. Here's an example. If it sets to `{"login_server": "properties.loginServer", "quarantine_status": "properties.policies.quarantinePolicy.status"}`, it will set the following HCL object to the computed property output.
    *
    * 	```text
    * 	{
    * 		"login_server" = "registry1.azurecr.io"
    * 		"quarantine_status" = "disabled"
    * 	}
    * 	```
    *
    * To learn more about JMESPath, visit [JMESPath](https://jmespath.org/).
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/azure/azapi/2.13.0/docs/data-sources/resource_action#response_export_values DataAzapiResourceAction#response_export_values}
    */
    readonly responseExportValues?: {
        [key: string]: any;
    };
    /**
    * The retry object supports the following attributes:
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/azure/azapi/2.13.0/docs/data-sources/resource_action#retry DataAzapiResourceAction#retry}
    */
    readonly retry?: DataAzapiResourceActionRetry;
    /**
    * The attribute can accept either a list or a map.
    *
    * - **List**: A list of paths that need to be exported from the response body. Setting it to `["*"]` will export the full response body. Here's an example. If it sets to `["properties.loginServer", "properties.policies.quarantinePolicy.status"]`, it will set the following HCL object to the computed property sensitive_output.
    *
    * 	```text
    * 	{
    * 		properties = {
    * 			loginServer = "registry1.azurecr.io"
    * 			policies = {
    * 				quarantinePolicy = {
    * 					status = "disabled"
    * 				}
    * 			}
    * 		}
    * 	}
    * 	```
    *
    * - **Map**: A map where the key is the name for the result and the value is a JMESPath query string to filter the response. Here's an example. If it sets to `{"login_server": "properties.loginServer", "quarantine_status": "properties.policies.quarantinePolicy.status"}`, it will set the following HCL object to the computed property sensitive_output.
    *
    * 	```text
    * 	{
    * 		"login_server" = "registry1.azurecr.io"
    * 		"quarantine_status" = "disabled"
    * 	}
    * 	```
    *
    * To learn more about JMESPath, visit [JMESPath](https://jmespath.org/).
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/azure/azapi/2.13.0/docs/data-sources/resource_action#sensitive_response_export_values DataAzapiResourceAction#sensitive_response_export_values}
    */
    readonly sensitiveResponseExportValues?: {
        [key: string]: any;
    };
    /**
    * In a format like `<resource-type>@<api-version>`. `<resource-type>` is the Azure resource type, for example, `Microsoft.Storage/storageAccounts`. `<api-version>` is version of the API used to manage this azure resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/azure/azapi/2.13.0/docs/data-sources/resource_action#type DataAzapiResourceAction#type}
    */
    readonly type: string;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/azure/azapi/2.13.0/docs/data-sources/resource_action#timeouts DataAzapiResourceAction#timeouts}
    */
    readonly timeouts?: DataAzapiResourceActionTimeouts;
}
export interface DataAzapiResourceActionRetry {
    /**
    * A list of regular expressions to match against error messages. If any of the regular expressions match, the request will be retried.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/azure/azapi/2.13.0/docs/data-sources/resource_action#error_message_regex DataAzapiResourceAction#error_message_regex}
    */
    readonly errorMessageRegex: string[];
    /**
    * The base number of seconds to wait between retries.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/azure/azapi/2.13.0/docs/data-sources/resource_action#interval_seconds DataAzapiResourceAction#interval_seconds}
    */
    readonly intervalSeconds?: number;
    /**
    * The maximum number of seconds to wait between retries.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/azure/azapi/2.13.0/docs/data-sources/resource_action#max_interval_seconds DataAzapiResourceAction#max_interval_seconds}
    */
    readonly maxIntervalSeconds?: number;
    /**
    * The multiplier to apply to the interval between retries.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/azure/azapi/2.13.0/docs/data-sources/resource_action#multiplier DataAzapiResourceAction#multiplier}
    */
    readonly multiplier?: number;
    /**
    * The randomization factor to apply to the interval between retries. The formula for the randomized interval is: `RetryInterval * (random value in range [1 - RandomizationFactor, 1 + RandomizationFactor])`. Therefore set to zero `0.0` for no randomization.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/azure/azapi/2.13.0/docs/data-sources/resource_action#randomization_factor DataAzapiResourceAction#randomization_factor}
    */
    readonly randomizationFactor?: number;
}
export declare function dataAzapiResourceActionRetryToTerraform(struct?: DataAzapiResourceActionRetry | cdktn.IResolvable): any;
export declare function dataAzapiResourceActionRetryToHclTerraform(struct?: DataAzapiResourceActionRetry | cdktn.IResolvable): any;
export declare class DataAzapiResourceActionRetryOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataAzapiResourceActionRetry | cdktn.IResolvable | undefined;
    set internalValue(value: DataAzapiResourceActionRetry | cdktn.IResolvable | undefined);
    private _errorMessageRegex?;
    get errorMessageRegex(): string[];
    set errorMessageRegex(value: string[]);
    get errorMessageRegexInput(): string[] | undefined;
    private _intervalSeconds?;
    get intervalSeconds(): number;
    set intervalSeconds(value: number);
    resetIntervalSeconds(): void;
    get intervalSecondsInput(): number | undefined;
    private _maxIntervalSeconds?;
    get maxIntervalSeconds(): number;
    set maxIntervalSeconds(value: number);
    resetMaxIntervalSeconds(): void;
    get maxIntervalSecondsInput(): number | undefined;
    private _multiplier?;
    get multiplier(): number;
    set multiplier(value: number);
    resetMultiplier(): void;
    get multiplierInput(): number | undefined;
    private _randomizationFactor?;
    get randomizationFactor(): number;
    set randomizationFactor(value: number);
    resetRandomizationFactor(): void;
    get randomizationFactorInput(): number | undefined;
}
export interface DataAzapiResourceActionTimeouts {
    /**
    * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/azure/azapi/2.13.0/docs/data-sources/resource_action#read DataAzapiResourceAction#read}
    */
    readonly read?: string;
}
export declare function dataAzapiResourceActionTimeoutsToTerraform(struct?: DataAzapiResourceActionTimeouts | cdktn.IResolvable): any;
export declare function dataAzapiResourceActionTimeoutsToHclTerraform(struct?: DataAzapiResourceActionTimeouts | cdktn.IResolvable): any;
export declare class DataAzapiResourceActionTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataAzapiResourceActionTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: DataAzapiResourceActionTimeouts | cdktn.IResolvable | undefined);
    private _read?;
    get read(): string;
    set read(value: string);
    resetRead(): void;
    get readInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/azure/azapi/2.13.0/docs/data-sources/resource_action azapi_resource_action}
*/
export declare class DataAzapiResourceAction extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "azapi_resource_action";
    /**
    * Generates CDKTN code for importing a DataAzapiResourceAction resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataAzapiResourceAction to import
    * @param importFromId The id of the existing DataAzapiResourceAction that should be imported. Refer to the {@link https://registry.terraform.io/providers/azure/azapi/2.13.0/docs/data-sources/resource_action#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataAzapiResourceAction to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/azure/azapi/2.13.0/docs/data-sources/resource_action azapi_resource_action} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataAzapiResourceActionConfig
    */
    constructor(scope: Construct, id: string, config: DataAzapiResourceActionConfig);
    private _action?;
    get action(): string;
    set action(value: string);
    resetAction(): void;
    get actionInput(): string | undefined;
    private _body?;
    get body(): {
        [key: string]: any;
    };
    set body(value: {
        [key: string]: any;
    });
    resetBody(): void;
    get bodyInput(): {
        [key: string]: any;
    } | undefined;
    private _headers?;
    get headers(): {
        [key: string]: string;
    };
    set headers(value: {
        [key: string]: string;
    });
    resetHeaders(): void;
    get headersInput(): {
        [key: string]: string;
    } | undefined;
    get id(): string;
    private _method?;
    get method(): string;
    set method(value: string);
    resetMethod(): void;
    get methodInput(): string | undefined;
    private _output;
    get output(): cdktn.AnyMap;
    private _queryParameters?;
    get queryParameters(): {
        [key: string]: string[];
    } | cdktn.IResolvable;
    set queryParameters(value: {
        [key: string]: string[];
    } | cdktn.IResolvable);
    resetQueryParameters(): void;
    get queryParametersInput(): cdktn.IResolvable | {
        [key: string]: string[];
    } | undefined;
    private _resourceId?;
    get resourceId(): string;
    set resourceId(value: string);
    resetResourceId(): void;
    get resourceIdInput(): string | undefined;
    private _responseExportValues?;
    get responseExportValues(): {
        [key: string]: any;
    };
    set responseExportValues(value: {
        [key: string]: any;
    });
    resetResponseExportValues(): void;
    get responseExportValuesInput(): {
        [key: string]: any;
    } | undefined;
    private _retry;
    get retry(): DataAzapiResourceActionRetryOutputReference;
    putRetry(value: DataAzapiResourceActionRetry): void;
    resetRetry(): void;
    get retryInput(): cdktn.IResolvable | DataAzapiResourceActionRetry | undefined;
    private _sensitiveOutput;
    get sensitiveOutput(): cdktn.AnyMap;
    private _sensitiveResponseExportValues?;
    get sensitiveResponseExportValues(): {
        [key: string]: any;
    };
    set sensitiveResponseExportValues(value: {
        [key: string]: any;
    });
    resetSensitiveResponseExportValues(): void;
    get sensitiveResponseExportValuesInput(): {
        [key: string]: any;
    } | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    get typeInput(): string | undefined;
    private _timeouts;
    get timeouts(): DataAzapiResourceActionTimeoutsOutputReference;
    putTimeouts(value: DataAzapiResourceActionTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | DataAzapiResourceActionTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
